-- Original Code in English by Nick Steen

-- Translations Code by Adriweb (some original things from TI (J. Powers))
-- Thanks to Excale for the Help with Translations tricks

-- Version 2.2 (minor fixes for elements electrons layers)

platform.apilevel = '1.0' 

--------------------------------------------------------------------- Messages

message = {


["The"] = {
     en = "The",
     fr = ""
},
["Periodic"] = {
     en = "Periodic",
     fr = "     Table"
},
["Table"] = {
     en = "Table",
     fr = "Périodique"
},
["of"] = {
     en = "of",
     fr = "     des"
},

["Elements"] = {
     en = "Elements",
     fr = "        Elements"
},


["ancient times"] = {
     en = "ancient times",
     de = "antike",
     zh_CN = "远古时代",
     zh_TW = "遠古時代",
     es = "la antigüedad",
     it = "tempi antichi",
     da = "oldtiden",
     pt = "tempos antigos",
     se = "antiken",
     fr = "temps antiques"
},

["someone"] = {
     en = "someone",
     de = "jemand",
     zh_CN = "有人",
     zh_TW = "有人",
     es = "alguien",
     it = "qualcuno",
     da = "person",
     pt = "alguém",
     se = "någon",
     fr = "quelqu'un"
},

["unknown"] = {
     en = "unknown",
     de = "unbekannt",
     zh_CN = "未知",
     zh_TW = "未知",
     es = "desconocido",
     it = "sconosciuto",
     da = "ukendt",
     pt = "desconhecido",
     se = "okända",
     fr = "inconnu"
},
 	
["actinide"] = {
     en = "actinide",
     de = "Aktiniden",
     zh_CN = "锕系",
     zh_TW = "錒系",
     es = "actínidos",
     it = "attinidi",
     da = "aktinider",
     pt = "actinídeos",
     se = "aktinider",
     fr = "Actinides"
},
["alkali metal"] = {
     en = "alkali metal",
     de = "Alkali",
     zh_CN = "碱金属",
     zh_TW = "鹼金屬",
     es = "metal alcalino",
     it = "metalli alcalini",
     da = "alkali metal",
     pt = "metal alcalino",
     se = "alkalimetall",
     fr = "Métal alcalin"
},
["alkaline earth metal"] = {
     en = "alkaline earth metal",
     de = "Erdalkalimetall",
     zh_CN = "碱土金属",
     zh_TW = "鹼土金屬",
     es = "metal alcalino",
     it = "metallo alcalino-terrosi",
     da = "alkaliske jordarters metaller",
     pt = "metal alcalino-terrosos",
     se = "alkaliska jordartsmetaller",
     fr = "métal alcalino-terreux"
},
["Aluminum"] = {
     en = "Aluminum",
     de = "Aluminum",
     zh_CN = "铝",
     zh_TW = "鋁",
     es = "Aluminum",
     it = "Alluminio",
     da = "Aluminium",
     pt = "Aluminum",
     se = "Aluminium",
     fr = "Aluminium"
},
["Americium"] = {
     en = "Americium",
     de = "Americium",
     zh_CN = "镅",
     zh_TW = "镅",
     es = "Americio",
     it = "Americio",
     da = "Americium",
     pt = "Amerício",
     se = "Americium",
     fr = "Américium"
},
["ancient times"] = {
     en = "ancient times",
     de = "alten Zeiten",
     zh_CN = "远古时代",
     zh_TW = "遠古時代",
     es = "tiempos antiguos",
     it = "tempi antichi",
     da = "oldtiden",
     pt = "tempos antigos",
     se = "gamla tider",
     fr = "temps anciens"
},
["Antimony"] = {
     en = "Antimony",
     de = "Antimon",
     zh_CN = "锑",
     zh_TW = "銻",
     es = "antimonio",
     it = "Antimonio",
     da = "Antimon",
     pt = "Antimônio",
     se = "Antimon",
     fr = "Antimoine"
},
["Argon"] = {
     en = "Argon",
     de = "Argon",
     zh_CN = "氩",
     zh_TW = "氬",
     es = "Argón",
     it = "Argon",
     da = "Argon",
     pt = "Argon",
     se = "Argon",
     fr = "Argon"
},
["Arsenic"] = {
     en = "Arsenic",
     de = "Arsen",
     zh_CN = "砷",
     zh_TW = "砷",
     es = "Arsénico",
     it = "Arsenico",
     da = "Arsenik",
     pt = "Arsênico",
     se = "Arsenik",
     fr = "Arsenic"
},
["Astatine"] = {
     en = "Astatine",
     de = "Astat",
     zh_CN = "砹",
     zh_TW = "砹",
     es = "astato",
     it = "Astato",
     da = "Astatine",
     pt = "Astatine",
     se = "Astat",
     fr = "Astate"
},
["Atomic Number: "] = {
     en = "Atomic Number: ",
     de = "Atomic Number: ",
     zh_CN = "原子序数： ",
     zh_TW = "原子序數： ",
     es = "Número atómico:" ,
     it = "Numero Atomico: ",
     da = "Atomic tal: ",
     pt = "Número atômico: ",
     se = "Atomnummer: ",
     fr = "Numéro atomique: "
},
["Barium"] = {
     en = "Barium",
     de = "Barium",
     zh_CN = "钡",
     zh_TW = "鋇",
     es = "Bario",
     it = "Bario",
     da = "Barium",
     pt = "Bário",
     se = "Barium",
     fr = "Baryum"
},
["Berkelium"] = {
     en = "Berkelium",
     de = "Berkelium",
     zh_CN = "锫",
     zh_TW = "锫",
     es = "Berkelio",
     it = "Berkelio",
     da = "Berkelium",
     pt = "Berquélio",
     se = "Berkelium",
     fr = "Berkélium"
},
["Beryllium"] = {
     en = "Beryllium",
     de = "Beryllium",
     zh_CN = "铍",
     zh_TW = "鈹",
     es = "berilio",
     it = "Berillio",
     da = "Beryllium",
     pt = "Berílio",
     se = "Beryllium",
     fr = "Béryllium"
},
["Bismuth"] = {
     en = "Bismuth",
     de = "Wismut",
     zh_CN = "铋",
     zh_TW = "鉍",
     es = "Bismuto",
     it = "Bismuto",
     da = "Bismuth",
     pt = "Bismuto",
     se = "Bismuth",
     fr = "Bismuth"
},
["Bohrium"] = {
     en = "Bohrium",
     de = "Bohrium",
     zh_CN = "Bohrium",
     zh_TW = "Bohrium",
     es = "Bohrio",
     it = "Bohrio",
     da = "Bohrium",
     pt = "Bóhrio",
     se = "Bohrium",
     fr = "Bohrium"
},
["Boiling point: "] = {
     en = "Boiling point: ",
     de = "Boiling Point: ",
     zh_CN = "沸点 ",
     zh_TW = "沸點 ",
     es = "Punto de ebullición: ",
     it = "Punto di ebollizione: ",
     da = "Kogepunkt: ",
     pt = "Ponto de ebulição: ",
     se = "Kokpunkt: ",
     fr = "Point d'ébullition: "
},
["Boron"] = {
     en = "Boron",
     de = "Boron",
     zh_CN = "硼",
     zh_TW = "硼",
     es = "Boro",
     it = "Boro",
     da = "Boron",
     pt = "Boro",
     se = "Boron",
     fr = "Bore"
},
["Bromine"] = {
     en = "Bromine",
     de = "Brom",
     zh_CN = "溴",
     zh_TW = "溴",
     es = "Bromo",
     it = "Bromo",
     da = "Brom",
     pt = "Bromo",
     se = "Brom",
     fr = "Brome"
},
["Cadmium"] = {
     en = "Cadmium",
     de = "Cadmium",
     zh_CN = "镉",
     zh_TW = "鎘",
     es = "Cadmio",
     it = "Cadmio",
     da = "Cadmium",
     pt = "Cádmio",
     se = "Kadmium",
     fr = "Cadmium"
},
["Calcium"] = {
     en = "Calcium",
     de = "Calcium",
     zh_CN = "钙",
     zh_TW = "鈣",
     es = "Calcio",
     it = "Calcio",
     da = "Calcium",
     pt = "Calcium",
     se = "Kalcium",
     fr = "Calcium"
},
["Californium"] = {
     en = "Californium",
     de = "Californium",
     zh_CN = "锎",
     zh_TW = "锎",
     es = "Californio",
     it = "californio",
     da = "Californium",
     pt = "Califórnio",
     se = "Californium",
     fr = "Californium"
},
["Carbon"] = {
     en = "Carbon",
     de = "Carbon",
     zh_CN = "碳",
     zh_TW = "碳",
     es = "Carbon",
     it = "Carbon",
     da = "Carbon",
     pt = "Carbon",
     se = "Carbon",
     fr = "Carbone"
},
["Cerium"] = {
     en = "Cerium",
     de = "Cerium",
     zh_CN = "铈",
     zh_TW = "鈰",
     es = "Cerio",
     it = "Cerio",
     da = "Cerium",
     pt = "Cério",
     se = "Cerium",
     fr = "Cérium"
},
["Cesium"] = {
     en = "Cesium",
     de = "Cäsium",
     zh_CN = "铯",
     zh_TW = "銫",
     es = "cesio",
     it = "Cesio",
     da = "Cæsium",
     pt = "Césio",
     se = "Cesium",
     fr = "Césium"
},
["Chlorine"] = {
     en = "Chlorine",
     de = "Chlor",
     zh_CN = "氯",
     zh_TW = "氯",
     es = "Cloro",
     it = "Cloro",
     da = "Klorin",
     pt = "Cloro",
     se = "Klor",
     fr = "Chlore"
},
["Chromium"] = {
     en = "Chromium",
     de = "Chromium",
     zh_CN = "铬",
     zh_TW = "鉻",
     es = "Cromo",
     it = "Cromo",
     da = "Chrom",
     pt = "Chromium",
     se = "Krom",
     fr = "Chrome"
},
["Cobalt"] = {
     en = "Cobalt",
     de = "Cobalt",
     zh_CN = "钴",
     zh_TW = "鈷",
     es = "Cobalt",
     it = "cobalto",
     da = "Cobalt",
     pt = "Cobalt",
     se = "Cobalt",
     fr = "Cobalt"
},
["Copernicium"] = {
     en = "Copernicium",
     de = "Copernicium",
     zh_CN = "Copernicium",
     zh_TW = "Copernicium",
     es = "Copernicium",
     it = "Copernicium",
     da = "Copernicium",
     pt = "Copernicium",
     se = "Copernicium",
     fr = "Copernicium"
},
["Copper"] = {
     en = "Copper",
     de = "Copper",
     zh_CN = "铜",
     zh_TW = "銅",
     es = "Cobre",
     it = "Rame",
     da = "Kobber",
     pt = "Cobre",
     se = "Koppar",
     fr = "Cuivre"
},
["Crystal structure: "] = {
     en = "Crystal structure: ",
     de = "Crystal-Struktur: ",
     zh_CN = "晶体结构",
     zh_TW = "晶體結構",
     es = "Estructura cristalina: ",
     it = "struttura di cristallo: ",
     da = "Crystal struktur: ",
     pt = "Estrutura de cristal: ",
     se = "Crystal struktur: ",
     fr = "Structure cristalline: "
},
["cubic"] = {
     en = "cubic",
     de = "cubic",
     zh_CN = "立方",
     zh_TW = "立方",
     es = "cúbicos",
     it = "cubo",
     da = "cubic",
     pt = "cubic",
     se = "kubikmeter",
     fr = "cube"
},
["Cubic,                                               body centered"] = {
     en = "Cubic,                         body centered",
     de = "Cubic,                         Körper zentriert",
     zh_CN = "立方                        ，体心",
     zh_TW = "立方，                       體心",
     es = "Cubic,                         centrada en el cuerpo",
     it = "Cubic,                         corpo centrato",
     da = "Cubic,                         body centreret",
     pt = "Cubic,                         corpo centrado",
     se = "Cubic,                         kropp centrerad",
     fr = "Cubique                        centré (c.c)"
},
["cubic,           face centered"] = {
     en = "cubic,                          face centered",
     de = "cubic-,                         Gesichts-zentriert",
     zh_CN = "立方，                        面心",
     zh_TW = "立方，                        面心",
     es = "cara cúbicos,                   centrado",
     it = "cubi,                           faccia centrato",
     da = "kubiske,                        ansigt centreret",
     pt = "cara,                           centrado cúbicos",
     se = "kubik,                          ansikte centrerad",
     fr = "cubique                         à faces centrées (c.f.c)"
},
["Curium"] = {
     en = "Curium",
     de = "Curium",
     zh_CN = "锔",
     zh_TW = "鋦",
     es = "Curio",
     it = "Curio",
     da = "Curium",
     pt = "Curium",
     se = "Curium",
     fr = "Curium"
},
["Darmstadtium"] = {
     en = "Darmstadtium",
     de = "Darmstadtium",
     zh_CN = "Darmstadtium",
     zh_TW = "Darmstadtium",
     es = "Darmstadtium",
     it = "Darmstadtium",
     da = "Darmstadtium",
     pt = "Darmstadtium",
     se = "Darmstadtium",
     fr = "Darmstadtium"
},
["Density at 20 C: "] = {
     en = "Density at 20 C : ",
     de = "Dichte bei 20 C : ",
     zh_CN = "密度在20°C ： ",
     zh_TW = "密度在20°C ： ",
     es = "Densidad a 20°C : ",
     it = "Densità a 20°C : ",
     da = "Densitet ved 20 C : ",
     pt = "Densidade a 20 °C : ",
     se = "Densitet vid 20 C : ",
     fr = "Densité à 20°C : "
},
["Discovered by "] = {
     en = "Discovered by ",
     de = "by Entdeckt ",
     zh_CN = "发现 ",
     zh_TW = "發現 ",
     es = "Descubierto por ",
     it = "Scoperto da ",
     da = "Fundet af ",
     pt = "Descoberto por ",
     se = "upptäckt av ",
     fr = "Découvert par "
},
["Dubnium"] = {
     en = "Dubnium",
     de = "Dubnium",
     zh_CN = "Dubnium",
     zh_TW = "Dubnium",
     es = "Dubnio",
     it = "Dubnio",
     da = "Dubnium",
     pt = "Dúbnio",
     se = "Dubnium",
     fr = "Dubnium"
},
["Dysprosium"] = {
     en = "Dysprosium",
     de = "Dysprosium",
     zh_CN = "镝",
     zh_TW = "鏑",
     es = "Disprosio",
     it = "Disprosio",
     da = "Dysprosium",
     pt = "Disprósio",
     se = "Dysprosium",
     fr = "Dysprosium"
},
["Einsteinium"] = {
     en = "Einsteinium",
     de = "Einsteinium",
     zh_CN = "Einsteinium",
     zh_TW = "Einsteinium",
     es = "Einstenio",
     it = "Einsteinio",
     da = "Einsteinium",
     pt = "Einsteinio",
     se = "Einsteinium",
     fr = "Einsteinium"
},
["Electron configuration: "] = {
     en = "Electron configuration: ",
     de = "Electron-Konfiguration: ",
     zh_CN = "电子组态： ",
     zh_TW = "電子組態： ",
     es = "Configuración electrónica: ",
     it = "Configurazione elettronica: ",
     da = "Electron konfiguration: ",
     pt = "configuração eletrônica: ",
     se = "Electron-konfiguration: ",
     fr = "Configuration électronique: "
},
["Electronegativity (Pauling): "] = {
     en = "Electronegativity (Pauling): ",
     de = "Elektronegativität (Pauling): ",
     zh_CN = "电负性（鲍林）",
     zh_TW = "電負性（鮑林）",
     es = "Electronegatividad (Pauling): ",
     it = "Elettronegatività (Pauling): ",
     da = "Elektronnegativitet (Pauling): ",
     pt = "Eletronegatividade (Pauling): ",
     se = "Elektronegativitet (Pauling): ",
     fr = "Electronégativité (Pauling): "
},
["Erbium"] = {
     en = "Erbium",
     de = "Erbium",
     zh_CN = "掺",
     zh_TW = "摻",
     es = "erbio",
     it = "Erbium",
     da = "Erbium",
     pt = "Erbium",
     se = "Erbium",
     fr = "Erbium"
},
["Europium"] = {
     en = "Europium",
     de = "Europium",
     zh_CN = "铕",
     zh_TW = "銪",
     es = "Europio",
     it = "Europio",
     da = "Europium",
     pt = "Európio",
     se = "Europium",
     fr = "Europium"
},
["Fermium"] = {
     en = "Fermium",
     de = "Fermium",
     zh_CN = "镄",
     zh_TW = "鐨",
     es = "Fermio",
     it = "fermio",
     da = "Fermium",
     pt = "Férmio",
     se = "Fermium",
     fr = "Fermium"
},
["Fluorine"] = {
     en = "Fluorine",
     de = "Fluor",
     zh_CN = "无氟",
     zh_TW = "無氟",
     es = "Flúor",
     it = "Fluoro",
     da = "Fluor",
     pt = "Flúor",
     se = "Fluor",
     fr = "Fluor"
},
["Francium"] = {
     en = "Francium",
     de = "Francium",
     zh_CN = "钫",
     zh_TW = "鈁",
     es = "Francio",
     it = "Francio",
     da = "Francium",
     pt = "Francium",
     se = "Francium",
     fr = "Francium"
},
["Gadolinium"] = {
     en = "Gadolinium",
     de = "Gadolinium",
     zh_CN = "钆",
     zh_TW = "钆",
     es = "gadolinio",
     it = "Gadolinio",
     da = "Gadolinium",
     pt = "Gadolínio",
     se = "Gadolinium",
     fr = "Gadolinium"
},
["Gallium"] = {
     en = "Gallium",
     de = "Gallium",
     zh_CN = "镓",
     zh_TW = "鎵",
     es = "Galio",
     it = "Gallio",
     da = "Gallium",
     pt = "Gálio",
     se = "Gallium",
     fr = "Gallium"
},
["Germanium"] = {
     en = "Germanium",
     de = "Germanium",
     zh_CN = "锗",
     zh_TW = "鍺",
     es = "Germanio",
     it = "Germanio",
     da = "Germanium",
     pt = "Germânio",
     se = "Germanium",
     fr = "Germanium"
},
["Gold"] = {
     en = "Gold",
     de = "Gold",
     zh_CN = "金",
     zh_TW = "金",
     es = "Oro",
     it = "Gold",
     da = "Gold",
     pt = "Oro",
     se = "Guld",
     fr = "Or"
},
["Group: "] = {
     en = "Group: ",
     de = "Group:",
     zh_CN = "本集团",
     zh_TW = "本集團",
     es = "Grupo: ",
     it = "Gruppo: ",
     da = "Group: ",
     pt = "Grupo: ",
     se = "Koncernen: ",
     fr = "Groupe: "
},
["Hafnium"] = {
     en = "Hafnium",
     de = "Hafnium",
     zh_CN = "铪",
     zh_TW = "鉿",
     es = "Hafnio",
     it = "Afnio",
     da = "Hafnium",
     pt = "Háfnio",
     se = "Hafnium",
     fr = "Hafnium"
},
["Hassium"] = {
     en = "Hassium",
     de = "Hassium",
     zh_CN = "Hassium",
     zh_TW = "Hassium",
     es = "Hassio",
     it = "Hassio",
     da = "Hassium",
     pt = "Hassium",
     se = "Hassium",
     fr = "Hassium"
},
["Helium"] = {
     en = "Helium",
     de = "Helium",
     zh_CN = "氦",
     zh_TW = "氦",
     es = "Helio",
     it = "Elio",
     da = "Helium",
     pt = "Hélio",
     se = "Helium",
     fr = "Hélium"
},
["hexagonal"] = {
     en = "hexagonal",
     de = "hexagonal",
     zh_CN = "六角形",
     zh_TW = "六角形",
     es = "hexagonal",
     it = "esagonale",
     da = "sekskantet",
     pt = "hexagonal",
     se = "sexkantig",
     fr = "hexagonale"
},
["Holmium"] = {
     en = "Holmium",
     de = "Holmium",
     zh_CN = "钬",
     zh_TW = "钬",
     es = "Holmium",
     it = "Olmio",
     da = "Holmium",
     pt = "Holmium",
     se = "Holmium",
     fr = "Holmium"
},
["Hydrogen"] = {
     en = "Hydrogen",
     de = "Hydrogen",
     zh_CN = "氢",
     zh_TW = "氫",
     es = "Hidrógeno",
     it = "Idrogeno",
     da = "Hydrogen",
     pt = "Hydrogen",
     se = "Väte",
     fr = "Hydrogène"
},
["Ia"] = {
     en = "IA",
     de = "IA",
     zh_CN = "IA",
     zh_TW = "IA",
     es = "IA",
     it = "IA",
     da = "IA",
     pt = "IA",
     se = "IA",
     fr = "IA"
},
["Ib"] = {
     en = "IB",
     de = "IB",
     zh_CN = "IB",
     zh_TW = "IB",
     es = "IB",
     it = "IB",
     da = "IB",
     pt = "IB",
     se = "IB",
     fr = "IB"
},
["IIa"] = {
     en = "IIA",
     de = "IIA",
     zh_CN = "IIA",
     zh_TW = "IIA",
     es = "IIA",
     it = "IIA",
     da = "IIA",
     pt = "IIA",
     se = "IIA",
     fr = "IIA"
},
["IIb"] = {
     en = "IIB",
     de = "IIB",
     zh_CN = "IIB",
     zh_TW = "IIB",
     es = "IIB",
     it = "IIB",
     da = "IIB",
     pt = "IIB",
     se = "IIB",
     fr = "IIB"
},
["IIIa"] = {
     en = "IIIA",
     de = "IIIA",
     zh_CN = "第IIIA部",
     zh_TW = "第IIIA部",
     es = "IIIA",
     it = "IIIA",
     da = "IIIA",
     pt = "IIIA",
     se = "IIIA",
     fr = "IllA"
},
["IIIb"] = {
     en = "IIIB",
     de = "IIIB",
     zh_CN = "IIIB期",
     zh_TW = "IIIB期",
     es = "IIIB",
     it = "IIIB",
     da = "IIIB",
     pt = "IIIB",
     se = "IIIB",
     fr = "IIIB"
},
["Indium"] = {
     en = "Indium",
     de = "Indium",
     zh_CN = "铟",
     zh_TW = "銦",
     es = "Indio",
     it = "Indio",
     da = "Indium",
     pt = "Índio",
     se = "Indium",
     fr = "Indium"
},
["Iodine"] = {
     en = "Iodine",
     de = "Jod",
     zh_CN = "碘",
     zh_TW = "碘",
     es = "Yodo",
     it = "Iodio",
     da = "Iod",
     pt = "Iodine",
     se = "Jod",
     fr = "Iode"
},
["Ionisation energy: "] = {
     en = "1st Ionisation energy: ",
     de = "Ionisation 1 Energie: ",
     zh_CN = "电离能量： ",
     zh_TW = "電離能量： ",
     es = "Energía de ionización 1: ",
     it = "Energia di ionizzazione 1: ",
     da = "1 Ionisering energi: ",
     pt = "Energia de ionização 1: ",
     se = "1 Jonisering energiområdet: ",
     fr = "Energie de 1ère ionisation: "
},
["Iridium"] = {
     en = "Iridium",
     de = "Iridium",
     zh_CN = "铱星",
     zh_TW = "銥星",
     es = "Iridium",
     it = "Iridium",
     da = "Iridium",
     pt = "Iridium",
     se = "Iridium",
     fr = "Iridium"
},
["Iron"] = {
     en = "Iron",
     de = "Iron",
     zh_CN = "铁",
     zh_TW = "鐵",
     es = "Iron",
     it = "Iron",
     da = "Iron",
     pt = "Iron",
     se = "Iron",
     fr = "Fer"
},
["IVa"] = {
     en = "IVA",
     de = "IVA",
     zh_CN = "第IVA",
     zh_TW = "第IVA",
     es = "IVA",
     it = "IVA",
     da = "IVA",
     pt = "IVA",
     se = "IVA",
     fr = "IVA"
},
["IVb"] = {
     en = "IVB",
     de = "IVB",
     zh_CN = "四B",
     zh_TW = "四B",
     es = "IVB",
     it = "IVB",
     da = "IVB",
     pt = "IVB",
     se = "IVB",
     fr = "IVB"
},
["Krypton"] = {
     en = "Krypton",
     de = "Krypton",
     zh_CN = "氪",
     zh_TW = "氪",
     es = "Krypton",
     it = "Krypton",
     da = "Krypton",
     pt = "Krypton",
     se = "Krypton",
     fr = "Krypton"
},
["lanthanide"] = {
     en = "Lanthanide",
     de = "Lanthaniden",
     zh_CN = "镧系元素",
     zh_TW = "鑭系元素",
     es = "Lantánidos",
     it = "Lantanidi",
     da = "Lanthanide",
     pt = "Lantanídeos",
     se = "Lantanider",
     fr = "Lanthanides"
},
["Lanthanum"] = {
     en = "Lanthanum",
     de = "Lanthan",
     zh_CN = "镧",
     zh_TW = "鑭",
     es = "Lantano",
     it = "Lantanio",
     da = "Lanthan",
     pt = "Lantânio",
     se = "Lantan",
     fr = "Lanthane"
},
["Lawrencium"] = {
     en = "Lawrencium",
     de = "Lawrencium",
     zh_CN = "Lawrencium",
     zh_TW = "Lawrencium",
     es = "Laurencio",
     it = "Laurenzio",
     da = "Lawrencium",
     pt = "Laurêncio",
     se = "Lawrencium",
     fr = "Lawrencium"
},
["Lead"] = {
     en = "Lead",
     de = "Lead",
     zh_CN = "领导",
     zh_TW = "領導",
     es = "Plomo",
     it = "Lead",
     da = "Lead",
     pt = "Lead",
     se = "Lead",
     fr = "Plomb"
},
["Lithium"] = {
     en = "Lithium",
     de = "Lithium",
     zh_CN = "锂电",
     zh_TW = "鋰電",
     es = "Lithium",
     it = "Lithium",
     da = "Lithium",
     pt = "Lithium",
     se = "Lithium",
     fr = "Lithium"
},
["Lutetium"] = {
     en = "Lutetium",
     de = "Lutetium",
     zh_CN = "镥",
     zh_TW = "镥",
     es = "Lutecio",
     it = "lutezio",
     da = "Lutetium",
     pt = "Lutécio",
     se = "Lutetium",
     fr = "Lutécium"
},
["Magnesium"] = {
     en = "Magnesium",
     de = "Magnesium",
     zh_CN = "镁",
     zh_TW = "鎂",
     es = "Magnesio",
     it = "Il magnesio",
     da = "Magnesium",
     pt = "Magnésio",
     se = "Magnesium",
     fr = "Magnésium"
},
["Manganese"] = {
     en = "Manganese",
     de = "Mangan",
     zh_CN = "锰",
     zh_TW = "錳",
     es = "Manganeso",
     it = "Manganese",
     da = "Mangan",
     pt = "Manganês",
     se = "Mangan",
     fr = "Manganèse"
},
["Meitnerium"] = {
     en = "Meitnerium",
     de = "Meitnerium",
     zh_CN = "Meitnerium",
     zh_TW = "Meitnerium",
     es = "Meitnerio",
     it = "Meitnerio",
     da = "Meitnerium",
     pt = "Meitnério",
     se = "Meitnerium",
     fr = "Meitnerium"
},
["Melting point: "] = {
     en = "Melting point: ",
     de = "Schmelzpunkt: ",
     zh_CN = "熔点： ",
     zh_TW = "熔點： ",
     es = "Punto de fusión: ",
     it = "Punto di fusione: ",
     da = "Smeltepunkt: ",
     pt = "Ponto de fusão: ",
     se = "Smältpunkt: ",
     fr = "Température de fusion: "
},
["Mendelevium"] = {
     en = "Mendelevium",
     de = "Mendelevium",
     zh_CN = "钔",
     zh_TW = "鍆",
     es = "Mendelevio",
     it = "Mendelevio",
     da = "Mendelevium",
     pt = "Mendelévio",
     se = "Mendelevium",
     fr = "Mendélévium"
},
["Mercury"] = {
     en = "Mercury",
     de = "Mercury",
     zh_CN = "水星",
     zh_TW = "水星",
     es = "Mercury",
     it = "Mercury",
     da = "Mercury",
     pt = "Mercury",
     se = "Mercury",
     fr = "Mercure"
},
["Molybdenum"] = {
     en = "Molybdenum",
     de = "Molybdän",
     zh_CN = "钼",
     zh_TW = "鉬",
     es = "Molibdeno",
     it = "Molibdeno",
     da = "Molybdæn",
     pt = "Molibdênio",
     se = "Molybden",
     fr = "Molybdène"
},
["monoclinic"] = {
     en = "monoclinic",
     de = "monoklin",
     zh_CN = "斜",
     zh_TW = "斜",
     es = "monoclínica",
     it = "monoclino",
     da = "monoclinic",
     pt = "monoclínica",
     se = "monoclinic",
     fr = "monoclinique"
},
["Name: "] = {
     en = "Name: ",
     de = "Name: ",
     zh_CN = "名称： ",
     zh_TW = "名稱： ",
     es = "Nombre: ",
     it = "Nome: ",
     da = "Navn: ",
     pt = "Name: ",
     se = "Namn: ",
     fr = "Nom: "
},
["Neodymium"] = {
     en = "Neodymium",
     de = "Neodymium",
     zh_CN = "钕",
     zh_TW = "釹",
     es = "Neodimio",
     it = "neodimio",
     da = "Neodymium",
     pt = "Neodymium",
     se = "Neodym",
     fr = "Néodyme"
},
["Neon"] = {
     en = "Neon",
     de = "Neon",
     zh_CN = "霓虹灯",
     zh_TW = "霓虹燈",
     es = "Neon",
     it = "Neon",
     da = "Neon",
     pt = "Neon",
     se = "Neon",
     fr = "Néon"
},
["Neptunium"] = {
     en = "Neptunium",
     de = "Neptunium",
     zh_CN = "镎",
     zh_TW = "镎",
     es = "Neptunio",
     it = "Nettunio",
     da = "neptunium",
     pt = "Neptunium",
     se = "Neptunium",
     fr = "Neptunium"
},
["Nickel"] = {
     en = "Nickel",
     de = "Nickel",
     zh_CN = "镍",
     zh_TW = "鎳",
     es = "Nickel",
     it = "Nichel",
     da = "Nikkel",
     pt = "Nickel",
     se = "Nickel",
     fr = "Nickel"
},
["Niobium"] = {
     en = "Niobium",
     de = "Niobium",
     zh_CN = "铌",
     zh_TW = "鈮",
     es = "Niobio",
     it = "Niobio",
     da = "Niobium",
     pt = "Nióbio",
     se = "Niob",
     fr = "Niobium"
},
["Nitrogen"] = {
     en = "Nitrogen",
     de = "Nitrogen",
     zh_CN = "氮",
     zh_TW = "氮",
     es = "Nitrógeno",
     it = "Azoto",
     da = "Kvælstof",
     pt = "Nitrogênio",
     se = "Kväve",
     fr = "Azote"
},
["Nobelium"] = {
     en = "Nobelium",
     de = "Nobelium",
     zh_CN = "锘",
     zh_TW = "锘",
     es = "Nobelio",
     it = "Nobelio",
     da = "Nobelium",
     pt = "Nobélio",
     se = "Nobelium",
     fr = "Nobelium"
},
["noble gas"] = {
     en = "Noble gas",
     de = "Edelgas",
     zh_CN = "惰性气体",
     zh_TW = "惰性氣體",
     es = "Gases nobles",
     it = "Gas nobile",
     da = "ædelgas",
     pt = "gás nobre",
     se = "ädelgas",
     fr = "Gaz nobles"
},
["nonmetal"] = {
     en = "Nonmetal",
     de = "Nichtmetall",
     zh_CN = "非金属",
     zh_TW = "非金屬",
     es = "No metal",
     it = "Non metallici",
     da = "Ikke-metallisk",
     pt = "Não-metal",
     se = "Nonmetal",
     fr = "Non-métaux"
},
["Nr of natural isotopes: "] = {
     en = "Nr of natural isotopes: ",
     de = "Anzahl der natürlichen Isotope: ",
     zh_CN = "NR天然同位素： ",
     zh_TW = "NR天然同位素： ",
     es = "N º de isótopos naturales: ",
     it = "Numero di isotopi naturali: ",
     da = "Nr. af naturlige isotoper: ",
     pt = "N º de isótopos naturais: ",
     se = "Antal naturliga isotoper: ",
     fr = "Nbr d'isotopes naturels: "
},
["orthorhombic"] = {
     en = "orthorhombic",
     de = "orthorhombischen",
     zh_CN = "斜方晶系",
     zh_TW = "斜方晶系",
     es = "ortorrómbica",
     it = "ortorombica",
     da = "orthorhombic",
     pt = "ortorrômbico",
     se = "orthorhombic",
     fr = "orthorhombique"
},
["Osmium"] = {
     en = "Osmium",
     de = "Osmium",
     zh_CN = "锇",
     zh_TW = "鋨",
     es = "Osmio",
     it = "Osmio",
     da = "Osmium",
     pt = "Ósmio",
     se = "Osmium",
     fr = "Osmium"
},
["other metal"] = {
     en = "other metal",
     de = "andere Metall",
     zh_CN = "其他金属",
     zh_TW = "其他金屬",
     es = "metal",
     it = "metallici",
     da = "andet metal",
     pt = "metal demais",
     se = "andra metal",
     fr = "autre métal"
},
["Oxidation states: "] = {
     en = "Oxidation states: ",
     de = "Oxidation heißt es: ",
     zh_CN = "氧化指出： ",
     zh_TW = "氧化指出： ",
     es = "Estados de oxidación: ",
     it = "Stati di ossidazione: ",
     da = "Oxidation hedder det: ",
     pt = "Estados de oxidação: ",
     se = "Oxidationstillstånd: ",
     fr = "Etats d'oxydation: "
},
["Oxygen"] = {
     en = "Oxygen",
     de = "Oxygen",
     zh_CN = "氧",
     zh_TW = "氧",
     es = "Oxígeno",
     it = "Oxygen",
     da = "Oxygen",
     pt = "Oxygen",
     se = "Oxygen",
     fr = "Oxygène"
},
["Palladium"] = {
     en = "Palladium",
     de = "Palladium",
     zh_CN = "钯",
     zh_TW = "鈀",
     es = "Palladium",
     it = "Palladium",
     da = "Palladium",
     pt = "Palladium",
     se = "Palladium",
     fr = "Palladium"
},
["Period: "] = {
     en = "Period: ",
     de = "Period: ",
     zh_CN = "期内: ",
     zh_TW = "期內: ",
     es = "Periodo: ",
     it = "Periodo: ",
     da = "Periode: ",
     pt = "Período: ",
     se = "Period: ",
     fr = "Période: "
},
["Phosphorus"] = {
     en = "Phosphorus",
     de = "Phosphor",
     zh_CN = "磷",
     zh_TW = "磷",
     es = "Fósforo",
     it = "Fosforo",
     da = "Fosfor",
     pt = "Fósforo",
     se = "Phosphorus",
     fr = "Phosphore"
},
["Platinum"] = {
     en = "Platinum",
     de = "Platinum",
     zh_CN = "白金",
     zh_TW = "白金",
     es = "Platinum",
     it = "Platinum",
     da = "Platinum",
     pt = "Platinum",
     se = "Platinum",
     fr = "Platine"
},
["Plutonium"] = {
     en = "Plutonium",
     de = "Plutonium",
     zh_CN = "钚",
     zh_TW = "钚",
     es = "plutonio",
     it = "plutonio",
     da = "Plutonium",
     pt = "Plutônio",
     se = "plutonium",
     fr = "Plutonium"
},
["Polonium"] = {
     en = "Polonium",
     de = "Polonium",
     zh_CN = "钋",
     zh_TW = "釙",
     es = "Polonio",
     it = "Polonio",
     da = "Polonium",
     pt = "Polônio",
     se = "Polonium",
     fr = "Polonium"
},
["Potassium"] = {
     en = "Potassium",
     de = "Kalium",
     zh_CN = "钾",
     zh_TW = "鉀",
     es = "Potasio",
     it = "Potassio",
     da = "Kalium",
     pt = "Potássio",
     se = "Kalium",
     fr = "Potassium"
},
["Praseodymium"] = {
     en = "Praseodymium",
     de = "Praseodym",
     zh_CN = "镨",
     zh_TW = "镨",
     es = "Praseodimio",
     it = "Praseodimio",
     da = "Praseodymium",
     pt = "Praseodímio",
     se = "Praseodym",
     fr = "Praséodyme"
},
["Promethium"] = {
     en = "Promethium",
     de = "Promethium",
     zh_CN = "钷",
     zh_TW = "钷",
     es = "Prometio",
     it = "Prometeo",
     da = "Promethium",
     pt = "Promécio",
     se = "Prometium",
     fr = "Prométhium"
},
["Protactinium"] = {
     en = "Protactinium",
     de = "Protactinium",
     zh_CN = "镤",
     zh_TW = "镤",
     es = "Protactinio",
     it = "Protoattinio",
     da = "Protactinium",
     pt = "Protactinium",
     se = "Protactinium",
     fr = "Protactinium"
},
["Radium"] = {
     en = "Radium",
     de = "Radium",
     zh_CN = "镭",
     zh_TW = "鐳",
     es = "Radio",
     it = "Radium",
     da = "Radium",
     pt = "Radium",
     se = "Radium",
     fr = "Radium"
},
["Radon"] = {
     en = "Radon",
     de = "Radon",
     zh_CN = "氡气",
     zh_TW = "氡氣",
     es = "Radon",
     it = "Radon",
     da = "Radon",
     pt = "Radon",
     se = "Radon",
     fr = "Radon"
},
["Relative atomic weight (12C): "] = {
     en = "Relative atomic weight (12C): ",
     de = "Relative Atommasse (12. Jh.): ",
     zh_CN = "相对原子质量（12C）: ",
     zh_TW = "相對原子質量（12C）: ",
     es = "peso atómico relativo (12C): ",
     it = "Relative peso atomico (12C): ",
     da = "Relativ atomvægt (12C): ",
     pt = "peso atômico relativa (12C): ",
     se = "relativ atomvikt (12C): ",
     fr = "Masse atomique relatif (12C): "
},
["Rhenium"] = {
     en = "Rhenium",
     de = "Rhenium",
     zh_CN = "铼",
     zh_TW = "錸",
     es = "Renio",
     it = "Renio",
     da = "Rhenium",
     pt = "Rhenium",
     se = "Rhenium",
     fr = "Rhénium"
},
["Rhodium"] = {
     en = "Rhodium",
     de = "Rhodium",
     zh_CN = "铑",
     zh_TW = "銠",
     es = "Rodio",
     it = "Rodio",
     da = "Rhodium",
     pt = "Rhodium",
     se = "Rhodium",
     fr = "Rhodium"
},
["rhombohedral"] = {
     en = "Rhombohedral",
     de = "Rhomboedrischen",
     zh_CN = "三方",
     zh_TW = "三方",
     es = "Romboédricos",
     it = "Romboedrica",
     da = "Rhombohedral",
     pt = "Romboédrica",
     se = "Rhombohedral",
     fr = "Rhomboédrique"
},
["Roentgenium"] = {
     en = "Roentgenium",
     de = "Roentgenium",
     zh_CN = "Roentgenium",
     zh_TW = "Roentgenium",
     es = "Roentgenio",
     it = "Roentgenio",
     da = "Roentgenium",
     pt = "Roentgenium",
     se = "Roentgenium",
     fr = "Roentgenium"
},
["Rubidium"] = {
     en = "Rubidium",
     de = "Rubidium",
     zh_CN = "铷",
     zh_TW = "銣",
     es = "Rubidio",
     it = "Rubidio",
     da = "Rubidium",
     pt = "Rubídio",
     se = "Rubidium",
     fr = "Rubidium"
},
["Ruthenium"] = {
     en = "Ruthenium",
     de = "Ruthenium",
     zh_CN = "钌",
     zh_TW = "釕",
     es = "Rutenio",
     it = "Rutenio",
     da = "Ruthenium",
     pt = "Rutênio",
     se = "Ruthenium",
     fr = "Ruthénium"
},
["Rutherfordium"] = {
     en = "Rutherfordium",
     de = "Rutherfordium",
     zh_CN = "Rutherfordium",
     zh_TW = "Rutherfordium",
     es = "Rutherfordio",
     it = "Rutherfordio",
     da = "Rutherfordium",
     pt = "Rutherfordium",
     se = "Rutherfordium",
     fr = "Rutherfordium"
},
["Samarium"] = {
     en = "Samarium",
     de = "Samarium",
     zh_CN = "钐",
     zh_TW = "釤",
     es = "Samario",
     it = "Samario",
     da = "Samarium",
     pt = "Samário",
     se = "Samarium",
     fr = "Samarium"
},
["Scandium"] = {
     en = "Scandium",
     de = "Scandium",
     zh_CN = "钪",
     zh_TW = "鈧",
     es = "Escandio",
     it = "Scandium",
     da = "Scandium",
     pt = "Scandium",
     se = "Scandium",
     fr = "Scandium"
},
["Seaborgium"] = {
     en = "Seaborgium",
     de = "Seaborgium",
     zh_CN = "Seaborgium",
     zh_TW = "Seaborgium",
     es = "Seaborgio",
     it = "Seaborgio",
     da = "Seaborgium",
     pt = "Seabórgio",
     se = "Seaborgium",
     fr = "Seaborgium"
},
["Selenium"] = {
     en = "Selenium",
     de = "Selenium",
     zh_CN = "硒",
     zh_TW = "硒",
     es = "selenio",
     it = "Selenio",
     da = "Selen",
     pt = "Selenium",
     se = "Selenium",
     fr = "Sélénium"
},
["Silicon"] = {
     en = "Silicon",
     de = "Silicon",
     zh_CN = "硅",
     zh_TW = "矽",
     es = "Silicon",
     it = "Silicon",
     da = "Silicon",
     pt = "Silicon",
     se = "Silicon",
     fr = "Sillicium"
},
["Silver"] = {
     en = "Silver",
     de = "Silver",
     zh_CN = "银",
     zh_TW = "銀",
     es = "Silver",
     it = "Silver",
     da = "Silver",
     pt = "Silver",
     se = "Silver",
     fr = "Argent"
},
["Sodium"] = {
     en = "Sodium",
     de = "Sodium",
     zh_CN = "钠",
     zh_TW = "鈉",
     es = "Sodio",
     it = "Sodio",
     da = "Sodium",
     pt = "sódio",
     se = "Natrium",
     fr = "Sodium"
},
["Strontium"] = {
     en = "Strontium",
     de = "Strontium",
     zh_CN = "锶",
     zh_TW = "鍶",
     es = "El estroncio",
     it = "Stronzio",
     da = "Strontium",
     pt = "Estrôncio",
     se = "Strontium",
     fr = "Strontium"
},
["Sulfur"] = {
     en = "Sulfur",
     de = "Sulfur",
     zh_CN = "硫",
     zh_TW = "硫",
     es = "Azufre",
     it = "Sulfur",
     da = "Svovl",
     pt = "Sulfur",
     se = "Svavel",
     fr = "Soufre"
},
["Tantalum"] = {
     en = "Tantalum",
     de = "Tantal",
     zh_CN = "钽",
     zh_TW = "鉭",
     es = "Tantalio",
     it = "Tantalio",
     da = "Tantal",
     pt = "Tântalo",
     se = "Tantal",
     fr = "Tantale"
},
["Technetium"] = {
     en = "Technetium",
     de = "Technetium",
     zh_CN = "锝",
     zh_TW = "锝",
     es = "Tecnecio",
     it = "Tecnezio",
     da = "Technetium",
     pt = "Tecnécio",
     se = "Teknetium",
     fr = "Technétium"
},
["Tellurium"] = {
     en = "Tellurium",
     de = "Tellurium",
     zh_CN = "碲",
     zh_TW = "碲",
     es = "Telurio",
     it = "Tellurio",
     da = "Tellur",
     pt = "Telúrio",
     se = "Tellur",
     fr = "Tellure"
},
["Terbium"] = {
     en = "Terbium",
     de = "Terbium",
     zh_CN = "铽",
     zh_TW = "铽",
     es = "Terbio",
     it = "Terbio",
     da = "Terbium",
     pt = "Térbio",
     se = "Terbium",
     fr = "Terbium"
},
["tetragonal"] = {
     en = "tetragonal",
     de = "tetragonal",
     zh_CN = "四方",
     zh_TW = "四方",
     es = "tetragonal",
     it = "tetragonale",
     da = "tetragonal",
     pt = "tetragonal",
     se = "tetragonal",
     fr = "tétragonale"
},
["Thallium"] = {
     en = "Thallium",
     de = "Thallium",
     zh_CN = "铊",
     zh_TW = "鉈",
     es = "Talio",
     it = "Tallio",
     da = "Thallium",
     pt = "Tálio",
     se = "Tallium",
     fr = "Thallium"
},
["Thorium"] = {
     en = "Thorium",
     de = "Thorium",
     zh_CN = "钍",
     zh_TW = "釷",
     es = "Torio",
     it = "Torio",
     da = "Thorium",
     pt = "Thorium",
     se = "Torium",
     fr = "Thorium"
},
["Thulium"] = {
     en = "Thulium",
     de = "Thulium",
     zh_CN = "稀土",
     zh_TW = "稀土",
     es = "Tulio",
     it = "Tulio",
     da = "Thulium",
     pt = "Túlio",
     se = "Tulium",
     fr = "Thulium"
},
["The Game"] = {
     en = "The Game",
     de = "The Game",
     zh_CN = "The Game",
     zh_TW = "The Game",
     es = "El Juego",
     it = "The Game",
     da = "The Game",
     pt = "The Game",
     se = "The Game",
     fr = "Le Jeu"
},
["Tin"] = {
     en = "Tin",
     de = "Tin",
     zh_CN = "田",
     zh_TW = "田",
     es = "Tin",
     it = "Tin",
     da = "Tin",
     pt = "Tin",
     se = "Tin",
     fr = "Tin"
},
["Titanium"] = {
     en = "Titanium",
     de = "Titanium",
     zh_CN = "钛",
     zh_TW = "鈦",
     es = "Titanium",
     it = "Titanium",
     da = "Titanium",
     pt = "Titanium",
     se = "Titan",
     fr = "Titane"
},
["transition metal"] = {
     en = "transition metal",
     de = "transition metal",
     zh_CN = "过渡金属",
     zh_TW = "過渡金屬",
     es = "metal de transi.",
     it = "metalli di transi.",
     da = "overgang metal",
     pt = "metal de transição",
     se = "transition metal",
     fr = "métaux de transit."
},
["Tungsten"] = {
     en = "Tungsten",
     de = "Tungsten",
     zh_CN = "钨",
     zh_TW = "鎢",
     es = "Tungsten",
     it = "Tungsteno",
     da = "Tungsten",
     pt = "Tungsten",
     se = "Tungsten",
     fr = "Tungstène"
},
["Type: "] = {
     en = "Type: ",
     de = "Type: ",
     zh_CN = "类型： ",
     zh_TW = "類型： ",
     es = "Tipo: ",
     it = "Tipo: ",
     da = "Type: ",
     pt = "Type: ",
     se = "Typ: ",
     fr = "Type: "
},
["Ununbium"] = {
     en = "Ununbium",
     de = "Ununbium",
     zh_CN = "Ununbium",
     zh_TW = "Ununbium",
     es = "Ununbium",
     it = "Ununbio",
     da = "Ununbium",
     pt = "Ununbium",
     se = "Ununbium",
     fr = "Ununbium"
},
["Ununhexium"] = {
     en = "Ununhexium",
     de = "Ununhexium",
     zh_CN = "Ununhexium",
     zh_TW = "Ununhexium",
     es = "Ununhexium",
     it = "Ununhexium",
     da = "Ununhexium",
     pt = "Ununhexium",
     se = "Ununhexium",
     fr = "Ununhexium"
},
["Ununnilium"] = {
     en = "Ununnilium",
     de = "Ununnilium",
     zh_CN = "Ununnilium",
     zh_TW = "Ununnilium",
     es = "Ununnilium",
     it = "Ununnilium",
     da = "Ununnilium",
     pt = "Ununnilium",
     se = "Ununnilium",
     fr = "Ununnilium"
},
["Ununoctium"] = {
     en = "Ununoctium",
     de = "Ununoctium",
     zh_CN = "Ununoctium",
     zh_TW = "Ununoctium",
     es = "Ununoctium",
     it = "Ununoctio",
     da = "Ununoctium",
     pt = "Ununoctium",
     se = "Ununoctium",
     fr = "Ununoctium"
},
["Ununpentium"] = {
     en = "Ununpentium",
     de = "Ununpentium",
     zh_CN = "Ununpentium",
     zh_TW = "Ununpentium",
     es = "Ununpentio",
     it = "Ununpentio",
     da = "Ununpentium",
     pt = "Ununpentium",
     se = "Ununpentium",
     fr = "Ununpentium"
},
["Ununquadium"] = {
     en = "Ununquadium",
     de = "Ununquadium",
     zh_CN = "Ununquadium",
     zh_TW = "Ununquadium",
     es = "ununquadio",
     it = "Ununquadio",
     da = "Ununquadium",
     pt = "Ununquadium",
     se = "Ununquadium",
     fr = "Ununquadium"
},
["Ununseptium"] = {
     en = "Ununseptium",
     de = "Ununseptium",
     zh_CN = "Ununseptium",
     zh_TW = "Ununseptium",
     es = "Ununseptium",
     it = "Ununseptio",
     da = "Ununseptium",
     pt = "Ununseptium",
     se = "Ununseptium",
     fr = "Ununseptium"
},
["Ununtrium"] = {
     en = "Ununtrium",
     de = "Ununtrium",
     zh_CN = "Ununtrium",
     zh_TW = "Ununtrium",
     es = "Ununtrium",
     it = "Ununtrio",
     da = "Ununtrium",
     pt = "Ununtrium",
     se = "Ununtrium",
     fr = "Ununtrium"
},
["Unununium"] = {
     en = "Unununium",
     de = "Unununium",
     zh_CN = "Unununium",
     zh_TW = "Unununium",
     es = "Unununium",
     it = "Unununium",
     da = "Unununium",
     pt = "Unununium",
     se = "Unununium",
     fr = "Unununium"
},
["Uranium"] = {
     en = "Uranium",
     de = "Uranium",
     zh_CN = "铀",
     zh_TW = "鈾",
     es = "uranio",
     it = "Uranio",
     da = "Uran",
     pt = "Uranium",
     se = "Uran",
     fr = "Uranium"
},
["Va"] = {
     en = "VA",
     de = "VA",
     zh_CN = "VA",
     zh_TW = "VA",
     es = "VA",
     it = "VA",
     da = "VA",
     pt = "VA",
     se = "VA",
     fr = "VA"
},
["Vanadium"] = {
     en = "Vanadium",
     de = "Vanadium",
     zh_CN = "钒",
     zh_TW = "釩",
     es = "Vanadium",
     it = "Vanadium",
     da = "Vanadium",
     pt = "Vanádio",
     se = "Vanadin",
     fr = "Vanadium"
},
["Vb"] = {
     en = "VB",
     de = "VB",
     zh_CN = "VB",
     zh_TW = "VB",
     es = "VB",
     it = "VB",
     da = "VB",
     pt = "VB",
     se = "VB",
     fr = "VB"
},
["VIa"] = {
     en = "VIA",
     de = "VIA",
     zh_CN = "内经",
     zh_TW = "內經",
     es = "VIA",
     it = "VIA",
     da = "VIA",
     pt = "VIA",
     se = "VIA",
     fr = "VIA"
},
["VIb"] = {
     en = "VIB",
     de = "VIB",
     zh_CN = "VIB",
     zh_TW = "VIB",
     es = "VIB",
     it = "VIB",
     da = "VIB",
     pt = "VIB",
     se = "VIB",
     fr = "VIB"
},
["VIIa"] = {
     en = "VIIA",
     de = "VIIA",
     zh_CN = "VIIA",
     zh_TW = "VIIA",
     es = "VIIA",
     it = "VIIA",
     da = "VIIA",
     pt = "VIIA",
     se = "VIIA",
     fr = "VIIA"
},
["VIIb"] = {
     en = "VIIB",
     de = "VIIB",
     zh_CN = "VIIB",
     zh_TW = "VIIB",
     es = "VIIB",
     it = "VIIB",
     da = "VIIB",
     pt = "VIIB",
     se = "VIIB",
     fr = "VIIB"
},
["VIIIb"] = {
     en = "VIIIB",
     de = "VIIIB",
     zh_CN = "VIIIB",
     zh_TW = "VIIIB",
     es = "VIIIB",
     it = "VIIIB",
     da = "VIIIB",
     pt = "VIIIB",
     se = "VIIIB",
     fr = "VIIIB"
},
["Xenon"] = {
     en = "Xenon",
     de = "Xenon",
     zh_CN = "氙气",
     zh_TW = "氙氣",
     es = "Xenon",
     it = "Xenon",
     da = "Xenon",
     pt = "Xenon",
     se = "Xenon",
     fr = "Xénon"
},
["Ytterbium"] = {
     en = "Ytterbium",
     de = "Ytterbium",
     zh_CN = "镱",
     zh_TW = "鐿",
     es = "Iterbio",
     it = "Itterbio",
     da = "Ytterbium",
     pt = "Itérbio",
     se = "Ytterby",
     fr = "Ytterbium"
},
["Yttrium"] = {
     en = "Yttrium",
     de = "Yttrium",
     zh_CN = "钇",
     zh_TW = "釔",
     es = "Itrio",
     it = "Ittrio",
     da = "Yttrium",
     pt = "Itrio",
     se = "Yttrium",
     fr = "Yttrium"
},
["Zinc"] = {
     en = "Zinc",
     de = "Zinc",
     zh_CN = "锌",
     zh_TW = "鋅",
     es = "Zinc",
     it = "Zinco",
     da = "Zinc",
     pt = "Zinco",
     se = "Zink",
     fr = "Zinc"
},
["Zirconium"] = {
     en = "Zirconium",
     de = "Zirconium",
     zh_CN = "锆",
     zh_TW = "鋯",
     es = "Zirconio",
     it = "Zirconio",
     da = "Zirconium",
     pt = "Zircônio",
     se = "Zirkonium",
     fr = "Zirconium"
},
["in"]= {
     en = " in ",
     de = " in ",
     zh_CN = " in ",
     zh_TW = " in ",
     es = " en ",
     it = " en ",
     da = " in ",
     pt = " in ",
     se = " in ",
     fr = " en "
},
 	

}


function L(key)
   local lang = locale.name()
   local tbl = message[key]
   return tbl and (tbl[lang] or tbl[lang:sub(1, 2)]) or key
end

function on.create()
pse_db = {
{L("Actinium"),"Ac",89,227,5,5.17,1.1,1050,3200,10.07,"[Rn] 6d1 7s2","Andre Debierne",1899,1,4,"+III"},
{L("Aluminum"),"Al",13,26.9815,3,5.9858,1.5,660,2467,2.7,"[Ne] 3s2 3p1","Hans Christian Oersted",1825,1,3,"+III"},
{L("Americium"),"Am",95,243,5,5.9738,1.3,994,2607,13.67,"[Rn] 5f7 7s2","G.T. Seaborg",1945,4,8,"+III, +IV, +V, +VI"},
{L("Antimony"),"Sb",51,121.76,3,8.6084,1.9,630,1750,6.684,"[Kr] 4d10 5s2 5p3",L("someone"),L("ancient times"),4,12,"+III, +V, -III"},
{L("Argon"),"Ar",18,39.948,4,15.7596,"no EN",-189,-186,1.784,"[Ne] 3s2 3p6","Sir Ramsay",1894,1,6,"0"},
{L("Arsenic"),"As",33,74.92,1,9.7886,2.0,81,613,5.7,"[Ar] 3d10 4s2 4p3",L("someone"),L("ancient times"),5,8,"+III, +V, -III"},
{L("Astatine"),"At",85,210,1,9.3,2.2,302,337,L("unknown"),"[Xe] 4f14 5d10 6s2 6p5",L("someone"),L("ancient times"),L("unknown"),7,L("unknown")},
{L("Barium"),"Ba",56,137.327,8,5.2117,0.9,725,1640,3.5,"[Xe] 6s2","Sir Humprey Davy",1808,2,16,"+II"},
{L("Berkelium"),"Bk",97,247,5,6.1979,1.3,986,L("unknown"),L("unknown"),"[Rn] 5f9 7s2","G.T. Seaborg",1949,L("unknown"),8,"+III, +IV"},
{L("Beryllium"),"Be",4,9.0122,8,9.3227,1.5,1278,2970,1.86,"[He] 2s2","Abbe Rene-Justt Hauy",1798,4,1,"+III"},
{L("Bismuth"),"Bi",83,208.9804,3,7.2856,1.9,271,1560,9.80,"[Xe] 4f14 5d10 6s2 6p3",L("unknown"),L("ancient times"),6,14,"+III, +V"},
{L("Bohrium"),"Bh",107,264,2,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),"[Rn] 5f14 6d5 7s2","Peter Armbuster and Gottfried Munzenber",1976,L("unknown"),3,L("unknown")},
{L("Boron"),"B",5,10.811,1,8.298,2.0,2300,2550,2.3,"[He] 2s2 2p1","Sir Humphry Davy and J.L Gay-Lussac",1808,5,2,"+III"},
{L("Bromine"),"Br",35,79.904,1,11.8138,2.8,-7,58.8,3.1,"[Ar] 3d10 4s2 4p5","Anthoine Balard",1826,3,10,"+I, +V, -I"},
{L("Cadmium"),"Cd",48,112.411,2,8.9938,1.7,321,765,8.7,"[Kr] 4d10 5s2","Fredrich Stromeyer",1817,4,15,"+II"},
{L("Calcium"),"Ca",20,40.078,8,6.1132,1.0,839,1484,1.6,"[Ar] 4s2","Sir Humphrey Davy",1808,1,10,"+II"},
{L("Californium"),"Cf",98,251,5,6.2817,L("unknown"),900,L("unknown"),L("unknown"),"[Rn] 5f9 6d1 7s2","G.T. Seaborg",1950,L("unknown"),10,"+III"},
{L("Carbon"),"C",6,12.0107,1,11.2603,2.5,3500,4827,2.2,"[He] 2s2 2p2",L("unknown"),L("ancient times"),4,3,"+II, +IV, -IV"},
{L("Cerium"),"Ce",58,140.116,6,5.5387,1.1,795,3257,6.76,"[Xe] 4f1 5d1 6s2","W. von Hisinger",1903,4,9,"+III, +IV"},
{L("Cesium"),"Cs",55,132.9055,7,3.8939,0.7,29,678,1.9,"[Xe] 6s1","Fustov Kirchhoff",1860,2,12,"+I"},
{L("Chlorine"),"Cl",17,35.453,1,12.9676,3.0,-101,-35,0.00321,"[Ne] 3s2 3p5","Carl Wilhelm Scheele",1774,5,4,"+I, +V, +VII, -I"},
{L("Chromium"),"Cr",24,51.9961,2,6.7665,1.55,1857,2672,7.19,"[Ar] 3d5 4s1","Vaughlin",1797,2,6,"+II, +III, +VI"},
{L("Cobalt"),"Co",27,58.9332,2,7.881,1.91,1495,2870,8.9,"[Ar] 3d7 4s2","George Brandt",1737,4,8,"+II, +III"},
{L("Copernicium"),"Cn",112,277,2,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),"S. Hofmann, V. Ninov and F.P. Hessbuger",1996,L("unknown"),1,L("unknown")},
{L("Copper"),"Cu",29,63.546,2,7.7264,1.65,1083,2567,8.9,"[Ar] 3d10 4s1",L("unknown"),L("ancient times"),1,6,"+I, +II"},
{L("Curium"),"Cm",96,247,5,5.9915,1.28,1340,L("unknown"),13.51,"[Rn],5f7 6d1 7s2","G.T. Seaborg",1944,L("unknown"),10,"+III, +IV"},
{L("Darmstadtium"),"Ds",110,268,2,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),"Albert Ghiorso",1970,L("unknown"),1,L("unknown")},
{L("Dubnium"),"Db",105,262,2,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),"Albert Ghiorso",1970,L("unknown"),1,L("unknown")},
{L("Dysprosium"),"Dy",66,162.5,6,5.9389,1.2,1412,2562,8.6,"[Xe] 4f10 6s2","Paul Emile Lecoq de Boisbaudran",1886,4,12,"+III"},
{L("Einsteinium"),"Es",99,252,5,6.42,1.3,860,L("unknown"),L("unknown"),"[Rn] 5f10 6d1 7s2","Argonne",1952,L("unknown"),10,L("unknown")},
{L("Erbium"),"Er",68,167.259,6,6.1077,1.22,1522,2510,9.2,"[Xe] 4f12 6s2","Carl Mosander",1843,4,9,"+III"},
{L("Europium"),"Eu",63,151.964,6,5.6704,1.2,822,1597,9.2,"[Xe] 4f7 6s2","Carl Mosander",1843,4,35,"+II, +III"},
{L("Fermium"),"Fm",100,257,5,6.5,1.3,1527,L("unknown"),L("unknown"),"[Rn] 5f11 6d1 7s2","Ghiorso",1952,L("unknown"),1,L("unknown")},
{L("Fluorine"),"F",9,18.9984,1,17.4228,3.98,-220,-188,1.96,"[He] 2s2 2p5","Moissan",1886,3,2,"-I"},
{L("Francium"),"Fr",87,223,7,4.0727,0.7,27,677,L("unknown"),"[Rn] 7s1","Marguerite Perey",1939,2,4,"+I"},
{L("Gadolinium"),"Gd",64,157.25,6,6.1501,1.17,1311,3233,7.9,"[Xe] 4f7 5d1 6s2","Jean de Marignac",1880,4,13,"+III"},
{L("Gallium"),"Ga",31,69.723,3,5.9993,2.01,30,2403,5.1,"[Ar] 3d10 4s2 4p1",L("unknown"),L("unknown"),7,6,"+III"},
{L("Germanium"),"Ge",32,72.64,3,7.8994,1.8,937,2830,5.3,"[Ar] 3d10 4s2 4p2","Clemens Winkler",1886,1,9,"+II, +IV"},
{L("Gold"),"Au",79,196.9665,2,9.2255,2.2,1064,2807,19.3,"[Xe] 4f14 5d10 6s1",L("unknown"),L("ancient times"),1,7,"+I, +III"},
{L("Hafnium"),"Hf",72,178.49,2,6.8251,1.3,2150,5400,13.07,"[Xe] 4f14 5d2 6s2","Dirk Coster",1923,4,10,"+IV"},
{L("Hassium"),"Hs",108,277,2,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),1,L("unknown")},
{L("Helium"),"He",2,4.0026,4,24.5874,"no EN",-272,-269,0.00178,"1s2","Sir Ramsey",1895,4,2,"0"},
{L("Holmium"),"Ho",67,164.9303,6,6.0215,0.2,1470,2720,8.8,"[Xe] 4f11 6s2","J.L. Soret",1878,4,4,"+III"},
{L("Hydrogen"),"H",1,1.0079,1,13.5984,2.2,-259,-253,0.0000899,"1s1","Henry Cavendish",1766,4,3,"+I, -I"},
{L("Indium"),"In",49,114.818,3,5.7864,1.69,157,2000,7.31,"[Kr] 4d10 5s2 5p1","Ferdinand Reich",1863,8,11,"+III"},
{L("Iodine"),"I",53,126.9045,1,10.4513,2.05,114,184,4.93,"[Kr] 4d10 5s2 5p5","Bernard Courtois",1811,7,15,"+I, +V, +VII, -I"},
{L("Iridium"),"Ir",77,192.217,2,8.967,1.9,2410,4527,22.4,"[Xe] 4f14 5d7 6s2","Smithson Tennant",1804,1,11,"+III, +IV"},
{L("Iron"),"Fe",26,55.845,2,7.9024,1.88,1535,2750,7.8,"[Ar] 3d6 4s2",L("unknown"),L("ancient times"),2,8,"+II, +III"},
{L("Krypton"),"Kr",36,83.8,4,13.9996,L("unknown"),-157,-153,3.73,"[Ar] 3d10 4s2 4p6","Sir Ramsey",1898,1,15,"0"},
{L("Lanthanum"),"La",57,138.9055,6,5.5769,0.79,920,3469,6.18,"[Xe] 5d1 6s2","Carl Monsander",1839,4,7,"+III"},
{L("Lawrencium"),"Lr",103,262,5,4.9,1.3,1627,L("unknown"),L("unknown"),"[Rn] 5f14 6d1 7s2","Albert Ghiosp",1961,L("unknown"),1,L("unknown")},
{L("Lead"),"Pb",82,207.2,3,7.4167,2.0,327,1740,11.34,"[Xe] 4f14 5d10 6s2 6p2",L("unknown"),L("ancient times"),1,13,"+II, +IV"},
{L("Lithium"),"Li",3,6.941,7,5.3917,0.98,180,1347,0.53,"[He] 2s1","Johann Arfvedson",1817,2,2,"+I"},
{L("Lutetium"),"Lu",71,174.967,6,5.4259,1.25,1656,3315,9.7,"[Xe] 4f14 5d1 6s2","George Urbain",1907,4,9,"+III"},
{L("Magnesium"),"Mg",12,24.305,8,7.6462,1.31,639,1090,1.74,"[Ne] 3s2","Sir Humphrey Davy",1808,4,5,"+II"},
{L("Manganese"),"Mn",25,54.938,2,7.434,1.83,1245,1962,7.43,"[Ar] 3d5 4s2","Johann Gahn",1774,2,7,"+II, +III, +IV, +VII"},
{L("Meitnerium"),"Mt",109,268,2,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),"Heavy ion research lab",1982,L("unknown"),1,L("unknown")},
{L("Mendelevium"),"Md",101,258,5,6.58,1.3,L("unknown"),L("unknown"),L("unknown"),"[Rn] 5f12 6d1 7s2","G.T. Seaborg",1955,L("unknown"),1,L("unknown")},
{L("Mercury"),"Hg",80,200.59,2,10.4375,2.28,-39,357,13.6,"[Xe] 4f14 5d10 6s2",L("unknown"),L("ancient times"),5,12,"+I, +II"},
{L("Molybdenum"),"Mo",42,95.94,2,7.0924,1.6,2617,4612,10.2,"[Kr] 4d5 5s1","Carl Wilhelm Scheele",1778,2,11,"+VI"},
{L("Neodymium"),"Nd",60,144.24,6,5.525,1.12,1010,3127,7.0,"[Xe] 4f4 6s2","Carl Auer von Welsbach",1885,4,9,"+III"},
{L("Neon"),"Ne",10,20.1797,4,21.5645,"no EN",-249,-246,0.9,"[He] 2s2 2p6","Sir Ramsey",1898,1,3,"0"},
{L("Neptunium"),"Np",93,237,5,6.2657,1.5,640,3902,20.25,"[Rn] 5f4 6d1 7s2","McMillan",1940,8,8,"+III, +IV, +V, +VI"},
{L("Nickel"),"Ni",28,58.6934,2,7.6398,1.9,1453,2732;8.9,"[Ar] 3d8 4s2","Alex Constedt",1751,1,10,"+II, +III"},
{L("Niobium"),"Nb",41,92.91,2,6.7589,1.33,2468,4927,8.4,"[Kr] 4d4 5s1","Chares Hatchett",1801,2,14,"+III, +V"},
{L("Nitrogen"),"N",7,14.0067,1,14.5341,3.04,-210,-196,1.2506,"[He] 2s2 2p3","Rutherford",1772,4,4,"+I, -I, +II, -II,+III, -III, +IV, V"},
{L("Nobelium"),"No",102,259,5,6.65,1.3,827,L("unknown"),L("unknown"),"[Rn] 5f13 6d1 7s2","Nobel institute for Physics",1957,L("unknown"),1,L("unknown")},
{L("Osmium"),"Os",76,190.23,2,8.4382,2.36,3045,5027,22.5,"[Xe] 4f14 5d6 6s2","Smithson Tennant",1803,4,13,"+III, +IV"},
{L("Oxygen"),"O",8,15.9994,1,13.6181,3.44,-218,-183,1.429,"[He] 2s2 2p4","Joseph Priestly",1774,3,4,"-II"},
{L("Palladium"),"Pd",46,106.42,2,8.3369,2.28,1552,2927,11.9,"[Kr] 4d10","William Wollaston",1803,1,9,"+II, +IV"},
{L("Phosphorus"),"P",15,30.9738,1,10.4867,2.19,44,280,1.82,"[Ne] 3s2 3p3","Hennig Brandt",1669,6,23,"+III, +V, -III"},
{L("Platinum"),"Pt",78,195.078,2,8.9587,2.2,1772,3827,21.4,"[Xe] 4f14 5d9 6s1","Julius Scaliger",1735,1,13,"+II, +IV"},
{L("Plutonium"),"Pu",94,244,5,6.0262,1.38,640,3235,19.84,"[Rn] 5f6 7s2","G.T. Seaborg",1940,6,11,"+III, +IV, +V, +VI"},
{L("Polonium"),"Po",84,209,3,8.417,2.33,254,962,9.51,"[Xe] 4f14 5d10 6s2 6p4","Pierre and Marie Curie",1898,6,12,"+II, +IV"},
{L("Potassium"),"K",19,39.0983,7,4.3407,0.82,64,760,0.86,"[Ar] 4s1","Sir Davy",1808,2,5,"+I"},
{L("Praseodymium"),"Pr",59,140.9077,6,5.473,1.1,935,3127,6.8,"[Xe] 4f3 6s2","Von Welsbach",1885,4,5,"+III"},
{L("Promethium"),"Pm",61,145,6,5.582,1.13,1100,3000,6.475,"[Xe] 4f5 6s2","Marinsky",1945,4,9,"+III"},
{L("Protactinium"),"Pa",91,231.0359,5,5.89,1.1,1568,L("unknown"),15.37,"[Rn] 5f2 6d1 7s2","K. Kajans and O.H. Gohring",1913,7,5,"+IV, +V"},
{L("Radium"),"Ra",88,226,8,5.2784,0.9,700,1737,5,"[Rn] 7s2","Pierre and Marie Curie",1898,2,6,"+II"},
{L("Radon"),"Rn",86,222,4,10.7485,"no EN",-71,-62,0.00996,"[Xe] 4f14 5d10 6s2 6p6","Fredrich Ernst Dorn",1898,1,7,"0"},
{L("Rhenium"),"Re",75,186.207,2,7.8335,1.5,3180,5627,20.5,"[Xe] 4f14 5d5 6s2","Walter Noddack",1925,4,9,"+IV, +VI, +VII"},
{L("Rhodium"),"Rh",45,102.9055,2,7.4589,2.2,1966,3727,12.4,"[Kr] 4d8 5s1","William Wollaston",1803,1,9,"+III"},
{L("Roentgenium"),"Ro",111,272,2,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),1},
{L("Rubidium"),"Rb",37,85.4678,7,4.1771,0.8,39,688,1.53,"[Kr] 5s1","Robert Wilhem Bunsen and Gustav Robert Kirchhoff",11861,2,11,"+I"},
{L("Ruthenium"),"Ru",44,101.07,2,7.3605,1.9,L("unknown"),3900,12.2,"[Kr] 4d7 5s1","Karl Klaus",1844,4,11,"+III"},
{L("Rutherfordium"),"Rf",104,261,2,L("unknown"),1.3,L("unknown"),L("unknown"),L("unknown"),"[Rn] 5f14 6d2 7s2","Lord Rutherford of Nelson",L("unknown"),L("unknown"),9,L("unknown")},
{L("Samarium"),"Sm",62,150.36,6,5.6437,1.14,1072,1900,6.9,"[Xe] 4f6 6s2","Paul Emile Lecoq de Boisbaudran",1879,4,11,"+II, +III"},
{L("Scandium"),"Sc",21,44.9559,6,6.5615,1.54,1539,2832,3.0,"[Ar] 3d1 4s2","Lars Nilson",1879,4,7,"+III"},
{L("Seaborgium"),"Sg",106,266,2,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),"[Rn] 7s2 5f14 6d4","Albert Ghiorso",1974,L("unknown"),1,L("unknown")},
{L("Selenium"),"Se",34,78.96,1,9.7524,2.55,217,685,4.79,"[Ar] 3d10 4s2 4p4","Jons Berzelius",1817,4,9,"+IV, +VI, -II"},
{L("Silicon"),"Si",14,28.0855,1,8.1517,1.9,1410,2355,2.33,"[Ne] 3s2 3p2","Jons Berzelius",1823,1,5,"+II, +IV, -IV"},
{L("Silver"),"Ag",47,107.8682,2,7.5762,2.2,962,2212,10.5,"[Kr] 4d10 5s1",L("unknown"),L("ancient times"),1,11,"+I"},
{L("Sodium"),"Na",11,22.9897,7,5.1391,0.93,98,883,0.97,"[Ne] 3s1","Sir Humphrey Davy",1807,2,3,"+I"},
{L("Strontium"),"Sr",38,87.62,8,5.6949,0.82,769,1384,2.6,"[Kr] 5s2","A. Crawford",1790,1,14,"+II"},
{L("Sulfur"),"S",16,32.065,1,10.36,2.58,113,445,2.07,"[Ne] 3s2 3p4",L("unknown"),L("ancient times"),5,5,"+IV, +VI, -II"},
{L("Tantalum"),"Ta",73,180.9479,2,7.5496,1.27,2996,5425,16.69,"[Xe] 4f14 5d3 6s2","Anders Ekeberg", 1802,2,4,"+V"},
{L("Technetium"),"Tc",43,98,2,7.28,1.9 ,2200,4877, 11.5,"[Kr] 4d5 5s2","Carlo Perrier",1937,4,9,"+IV, +VI, +VII"},
{L("Tellurium"),"Te",52,127.6,1,9.0096,2.1,449,990,6.24,"[Kr] 4d10 5s2 5p4","Franz Muller von Reichenstein",1782,4,23,"+IV, +VI, -II"},
{L("Terbium"),"Tb",65,158.9253,6,5.8638,1.2,1360,3041,8.3,"[Xe] 4f9 6s2","Carl Mosander",1843,4,9,"+III, +IV"},
{L("Thallium"),"Tl",81,204.3833,3,3.1082,2.54,303,1457,11.71,"[Xe] 4f14 5d10 6s2 6p1","Sir William Crookes",1861,7,11,"+I, +III"},
{L("Thorium"),"Th",90,232.0381,5,6.3067,0.89,1750,4790,11.72,"[Rn] 6d2 7s2","Jons Berzelius",18228,1,9,"+IV"},
{L("Thulium"),"Tm",69,168.9342,6,6.1843,1.23,1545,1727,9.3,"[Xe] 4f13 6s2","Theodore Cleve",1879,4,5,"+III"},
{L("Tin"),"Sn",50,118.71,3,7.3439,1.78,232,2270,7.28,"[Kr] 4d10 5s2 5p2",L("unknown"),L("ancient times"),8,20,"+II, +IV"},
{L("Titanium"),"Ti",22,47.867,2,6.8281,1.63,1660,3287,4.51,"[Kr] 3d2 4s2","William Gregor",1791,4,8,"+II, +III, +IV"},
{L("Tungsten"),"W",74,183.84,2,7.864,1.3,3410,5660,19.3,"[Xe] 4f14 5d4 6s2","Fausto and Juan Jose de Elhuyar ",1783,2,10,"+III"},
{L("Ununbium"),"Uub",112,277,2,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),"S. Hofmann, V. Ninov and F.P. Hessbuger",1996,L("unknown"),1,L("unknown")},
{L("Ununhexium"),"Uuh",116,263,3,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),"The Lawrence Berkeley National Laboratory",L("unknown"),L("unknown"),1,L("unknown")},
{L("Ununnilium"),"Uun",110,268,2,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),"Albert Ghiorso",1970,L("unknown"),1,L("unknown")}, --[[Darmstadtium]]
{L("Ununoctium"),"Uuo",118,293,4,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),"Berkeley Lab scientists",1999,L("unknown"),1,L("unknown")},
{L("Ununpentium"),"Uup",115,262,3,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),"JINR Dubna and LLNL california",2003,L("unknown"),L("unknown"),"+IV"},
{L("Ununquadium"),"Uuq",114,261,3,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),"JINR Dubna",1999,L("unknown"),L("unknown"),L("unknown")},
{L("Ununseptium"),"Uus",117,L("unknown"),3,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),"undiscovered",L("unknown"),L("unknown"),L("unknown")},
{L("Ununtrium"),"Uut",113,286,3,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),"JINR Dubna and LLNL california",2003,L("unknown"),L("unknown"),L("unknown")},
{L("Unununium"),"Uuu",111,272,2,L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown"),L("unknown")},
{L("Uranium"),"U",92,238.0289,5,6.1941,1.3,1132,3818,18.95,"[Rn] 5f3 6d1 7s2","Martin Klaproth",1789,3,11,"+III, +IV, +V, +VI"},
{L("Vanadium"),"V",23,50.9415,2,6.7462,1.66,1890,3380,6.1,"[Ar] 3d3 4s2","Nils Sefstrom",1830,2,5,"+II, +III, +IV, +V"},
{L("Xenon"),"Xe",54,131.293,4,12.1298,"no EN",-112,-108,0.0059,"[Kr] 4d10 5s2 5p6","Sir Ramsey",1898,1,21,"0"},
{L("Ytterbium"),"Yb",70,173.04,6,6.2542,1.24,824,1466,7.0,"[Xe] 4f14 6s2","Jean de Marignac",1878,1,9,"+II, +III"},
{L("Yttrium"),"Y",39,88.906,6,6.2173,0.95,1523,3337,4.47,"[Kr] 4d1 5s2","Johann Gadolin",1794,4,10,"+III"},
{L("Zinc"),"Zn",30,65.39,2,9.3942,1.81,420,907,7.11,"[Ar] 3d10 4s2","Andreas Marggraf",1746,4,10,"+II"},
{L("Zirconium"),"Zr",40,91.22,2,6.6339,1.22,1852,4377,6.49,"[Kr] 4d2 5s2","Martin Klaproth",1789,4,11,"+IV"}
}

pse_order = {
{44,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,42},
{53,10,0,0,0,0,0,0,0,0,0,0,13,18,66,69,34,62},
{93,55,0,0,0,0,0,0,0,0,0,0,2,91,71,95,21,5},
{75,16,88,104,116,22,56,48,23,64,25,120,37,38,6,90,14,49},
{84,94,119,121,65,60,97,85,82,70,92,15,45,103,4,98,46,117},
{20,8,54,40,96,105,81,68,47,72,39,59,100,52,11,74,7,80},
{35,79,51,86,28,89,12,41,57,108,114,106,113,111,110,107,112,109},

{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},

{0,0,0,0,50,19,76,61,77,87,32,36,99,29,43,31,102,118},
{0,0,0,0,1,101,78,115,63,73,3,26,9,17,30,33,58,67}
}

pse_link = {}

layout = "pse"
elsel = 0
border = false
if platform.isColorDisplay() then
	color = {{255,165,63},{193,186,216},{255,204,204},{221,224,52},{147,200,235},{139,205,173},{255,210,112},{255,154,133}}
	-- nonmetal=1/metal=2/semimetal=3/edel=4/actinide=5/lanthanide=6/alkali metals=7/alkaline earth metals=8
else
	color = {{170,170,170},{255,255,255},{255,255,255},{130,130,130},{255,255,255},{255,255,255},{255,255,255},{255,255,255}}
end	
types = {L("nonmetal"),L("transition metal"),L("other metal"),L("noble gas"),L("actinide"),L("lanthanide"),L("alkali metal"),L("alkaline earth metal")}
pse_groups = {{L("Ia"),0.35,1.3},{L("IIa"),1.3,2.3},{L("IIIb"),3.3,3.2},{L("IVb"),3.3,4.2},{L("Vb"),3.3,5.3},{L("VIb"),3.3,6.1},{L("VIIb"),3.3,7},{L("VIIIb"),3.3,9},{L("Ib"),3.3,11.3},{L("IIb"),3.3,12.3},{L("IIIa"),1.3,13.1},{L("IVa"),1.3,14.1},{L("Va"),1.3,15.2},{L("VIa"),1.3,16.1},{L("VIIa"),1.3,17},{L("VIIIa"),0.35,18.5}}
structures = {L("Cubic,                                               body centered"),L("cubic,           face centered"),L("cubic"),L("hexagonal"),L("rhombohedral"),L("monoclinic"),L("tetragonal"),L("orthorhombic")}
cubeVertices={}
cubeFaces={}
translate(cubeVertices,0,0,-3)
scale(cubeVertices,0.8,0.8,0.8)
--Lua Tiny3D - By Loic Pujet
interval = 0.05
--timer.start(interval)
nrofcubes = 1
cubedata = {{0,0,0,0,0,0}}
setcube = true

rowsel = 0
colsel = 0

	on.resize(platform.window:width(),platform.window:height())

end

function on.resize(x,y)
	XRatio = x/320
	YRatio = y/212
end

on.construction = on.create

---------------
-----PAINT-----
---------------

function on.paint(gc)
	if layout=="pse" then
		--gc:drawString(elsel,(0)*XRatio,(0)*YRatio,"top")
		gc:setColorRGB(0,0,0)
		gc:setFont("sansserif","r","6")
		for i=1,7 do
			gc:drawString(i,(1)*XRatio,(i*20-8)*YRatio,"top")
		end
		for i=1,16 do
			gc:drawString(pse_groups[i][1],(pse_groups[i][3]*17-9)*XRatio,(pse_groups[i][2]*20-10)*YRatio,"top")
		end
		for i=1,#pse_order do
			for j=1,#pse_order[i] do
				if pse_order[i][j]~=0 then
					gc:setColorRGB(unpack(color[pse_db[pse_order[i][j]][5]]))
					gc:fillRect((j*17-8)*XRatio,(i*20-10)*YRatio,(16)*XRatio,(19)*YRatio)
					--gc:setAlpha(255)
					gc:setColorRGB(0,0,0)
					gc:drawString(pse_db[pse_order[i][j]][2],(j*17-8)*XRatio,(i*20-4)*YRatio,"top")
					gc:drawString(pse_db[pse_order[i][j]][3],(j*17-7)*XRatio,(i*20-12)*YRatio,"top")
					if #pse_link ~= #pse_db then
						table.insert(pse_link,#pse_link,{j*17-9,i*20-10,17,19,pse_order[i][j],i,j})
					end
				end
			end
		end
		for i=1,8,2 do
			gc:setColorRGB(unpack(color[i]))
			gc:drawString(types[i],(8+(i-1)*35)*XRatio,(147)*YRatio,"top")
		end
		for i=2,9,2 do
			gc:setColorRGB(unpack(color[i]))
			gc:drawString(types[i],(8+(i-1)*35-35)*XRatio,(156)*YRatio,"top")
		end
		gc:setColorRGB(0,0,0)
		gc:drawString("6",(4*17+1)*XRatio,(9*20-8)*YRatio,"top")
		gc:drawString("7",(4*17+1)*XRatio,(10*20-8)*YRatio,"top")
		if XRatio == 1 then
		gc:drawPolyLine({8,10,  25,10,  25,29,  42,29,  42,69,  212,69,  212,29,   297,29,   297,10,   314,10,   314,149,   8,149,   8,10})
		gc:drawPolyLine({76,170,   314,170,   314,209,   76,209,   76,170})
		end
		gc:setFont("sansserif","r","6")
		gc:drawString(L("The"),(83)*XRatio,(20)*YRatio,"bottom")
		gc:setFont("sansserif","b","9")
		gc:drawString(L("Periodic"),(72)*XRatio,(30)*YRatio,"bottom")
		gc:setFont("sansserif","b","11")
		gc:drawString(L("Table"),(122)*XRatio,(32)*YRatio,"bottom")
		gc:setFont("sansserif","r","6")
		gc:drawString(L("of"),(92)*XRatio,(42)*YRatio,"bottom")
		gc:setFont("sansserif","b","9")
		gc:drawString(L("Elements"),(105)*XRatio,(45)*YRatio,"bottom")
		gc:setFont("sansserif","r","6")
		gc:drawString("Nick Steen",(1)*XRatio,(185)*YRatio,"top")
		gc:drawString("& TI-Planet",(1)*XRatio,(195)*YRatio,"top")
		-- End drawing fct pse
	elseif layout=="specs" then
-- {1 "name",2 "symbol",3 atomic number,4 atomic mass,5 nonmetal=1/metal=2/semimetal=3/edel=4,6 ionisation energy,7 EN,8 melting,9 boiling,10 dichtheid 20C,
-- 11 elctronen config,12 discovery name,13 year,14 crist struct(0ukwn,1cfc,2cbc,3c,4hex,5rhb,6mon,7trg,8ort),15 nr of natural isotopes}
		if pse_db[elsel][3]>=83 then
			gc:setFont("sansserif","b","10")
			w = gc:getStringWidth(L("Name: ")..pse_db[elsel][1].."  ( "..pse_db[elsel][2].." )")
			gc:drawImage(radioactive,w+10,5)
		end
		gc:setColorRGB(190,190,190)
		gc:fillPolygon({259,5,  262,5,   262,8,   265,8,   265,14,   295,14,   295,8,   310,8,   310,5,   313,5,   313,26,   259,26})
		gc:fillPolygon({271,29,   313,29,   313,35,   271,35})
		gc:setColorRGB(0,0,0)
		gc:fillPolygon({colsel*3+256,rowsel*3+2,  colsel*3+256+3,rowsel*3+2,   colsel*3+259,rowsel*3+5,   colsel*3+256,rowsel*3+5})
		gc:setFont("sansserif","b","10")
		gc:drawString(L("Name: ")..pse_db[elsel][1].."  ( "..pse_db[elsel][2].." )",(1)*XRatio,(0)*YRatio,"top")
		gc:setFont("sansserif","r","8")
		gc:drawString(L("Atomic Number: ")..pse_db[elsel][3],(1)*XRatio,(15)*YRatio,"top")
		gc:drawString(L("Relative atomic weight (12C): ")..pse_db[elsel][4],(1)*XRatio,(25)*YRatio,"top")
		gc:drawString(L("Type: ")..types[pse_db[elsel][5]],(1)*XRatio,(35)*YRatio,"top")
		gc:drawString(L("Ionisation energy: ")..pse_db[elsel][6],(1)*XRatio,(45)*YRatio,"top")
		gc:drawString(L("Electronegativity (Pauling): ")..pse_db[elsel][7],(1)*XRatio,(55)*YRatio,"top")
		if pse_db[elsel][8]~=L("unknown") then
			gc:drawString(L("Melting point: ")..(pse_db[elsel][8]+273.15).." K   ="..(pse_db[elsel][8]).." C   ="..(pse_db[elsel][8]*1.8+32).." F",(1)*XRatio,(65)*YRatio,"top")
		else
			gc:drawString(L("Melting point: ")..pse_db[elsel][8],(1)*XRatio,(65)*YRatio,"top")
		end
		if pse_db[elsel][9]~=L("unknown") then
			gc:drawString(L("Boiling point: ")..(pse_db[elsel][9]+273.15).." K   ="..(pse_db[elsel][9]).." C   ="..(pse_db[elsel][9]*1.8+32).." F",(1)*XRatio,(75)*YRatio,"top")
		else
			gc:drawString(L("Boiling point: ")..pse_db[elsel][9],(1)*XRatio,(75)*YRatio,"top")
		end
		gc:drawString(L("Density at 20 C: ")..pse_db[elsel][10].." g*cm^-3",(1)*XRatio,(85)*YRatio,"top")
		gc:drawString(L("Electron configuration: ")..pse_db[elsel][11],(1)*XRatio,(95)*YRatio,"top")
		gc:drawString(L("Discovered by ")..pse_db[elsel][12]..L("in")..pse_db[elsel][13],(1)*XRatio,(105)*YRatio,"top")
		gc:drawString(L("Nr of natural isotopes: ")..pse_db[elsel][15],(1)*XRatio,(115)*YRatio,"top")
		gc:drawString(L("Oxidation states: ")..pse_db[elsel][16],(1)*XRatio,(125)*YRatio,"top")
		if pse_db[elsel][14]~=L("unknown") and pse_db[elsel][14]>0 then
			gc:drawString(L("Crystal structure: ")..structures[pse_db[elsel][14]],(1)*XRatio,(135)*YRatio,"top")
		else
			gc:drawString(L("Crystal structure: ")..pse_db[elsel][14],(1)*XRatio,(135)*YRatio,"top")
		end
		gc:drawString(L("Group: ")..colsel,(259)*XRatio,(32)*YRatio,"top")
		gc:drawString(L("Period: ")..rowsel,(259)*XRatio,(42)*YRatio,"top")
		if pse_db[elsel][14]==2 then
			if setcube then
				cubeVertices={{-1,-1,-1},{1,-1,-1},{-1,1,-1},{-1,-1,1},{1,1,-1},{-1,1,1},{1,-1,1},{1,1,1},{0,0,-1},{0,0,1},{0,-1,0},{0,1,0},{1,0,0},{-1,0,0}}
				cubeFaces={{1,2,5,3},{1,4,6,3},{1,4,7,2},{8,7,4,6},{8,5,3,6},{8,5,2,7}}
				translate(cubeVertices,0,0,-3)
				scale(cubeVertices,0.8,0.8,0.8)
				setcube = false
			end
			render(gc,cubeVertices,cubeFaces,2,{200,0,0},8)
		elseif pse_db[elsel][14]==1 then
			if setcube then
				cubeVertices={{-1,-1,-1},{1,-1,-1},{-1,1,-1},{-1,-1,1},{1,1,-1},{-1,1,1},{1,-1,1},{1,1,1},{0,0,0}}
				cubeFaces={{1,2,5,3},{1,4,6,3},{1,4,7,2},{8,7,4,6},{8,5,3,6},{8,5,2,7}}
				translate(cubeVertices,0,0,-3)
				scale(cubeVertices,0.8,0.8,0.8)
				setcube = false
			end
			render(gc,cubeVertices,cubeFaces,2,{200,0,0},8)
		elseif pse_db[elsel][14]==3 then
			if setcube then
				cubeVertices={{-1,-1,-1},{1,-1,-1},{-1,1,-1},{-1,-1,1},{1,1,-1},{-1,1,1},{1,-1,1},{1,1,1}}
				cubeFaces={{1,2,5,3},{1,4,6,3},{1,4,7,2},{8,7,4,6},{8,5,3,6},{8,5,2,7}}
				translate(cubeVertices,0,0,-3)
				scale(cubeVertices,0.8,0.8,0.8)
				setcube = false
			end
			render(gc,cubeVertices,cubeFaces,2,{200,0,0},8)
		elseif pse_db[elsel][14]==5 then
			if setcube then
				cubeVertices={{-0.1,-1,1},{-0.1,1,1},{1.9,1,1},{1.9,-1,1},{-1,-1,-1},{-1,1,-1},{1,1,-1},{1,-1,-1}}
				cubeFaces={{1,2,3,4},{5,6,7,8},{1,2,6,5},{3,4,8,7}}
				translate(cubeVertices,0,0,-3)
				scale(cubeVertices,0.8,0.8,0.8)
				setcube = false
			end
			render(gc,cubeVertices,cubeFaces,2,{200,0,0},8)
		elseif pse_db[elsel][14]==4 then
			if setcube then
				cubeVertices={{0,-1,1},{-0.6,-0.6,1},{-0.6,0.6,1},{0,1,1},{0.6,0.6,1},{0.6,-0.6,1},{0,-1,-1},{-0.6,-0.6,-1},{-0.6,0.6,-1},{0,1,-1},{0.6,0.6,-1},{0.6,-0.6,-1}}
				cubeFaces={{1,2,3,4,5,6},{7,8,9,10,11,12},{1,2,8,7},{3,4,10,9},{5,6,12,11}}
				translate(cubeVertices,0,0,-3)
				scale(cubeVertices,0.8,0.8,0.8)
				setcube = false
			end
			render(gc,cubeVertices,cubeFaces,2,{200,0,0},8)
		elseif pse_db[elsel][14]==6 then
			if setcube then
				cubeVertices={{-0.3,-1,1},{-0.3,1,1},{1.1,1,1},{1.1,-1,1},{-0.5,-1,-1},{-0.5,1,-1},{0.7,1,-1},{0.7,-1,-1}}
				cubeFaces={{1,2,3,4},{5,6,7,8},{1,2,6,5},{3,4,8,7}}
				translate(cubeVertices,0,0,-3)
				scale(cubeVertices,0.8,0.8,0.8)
				setcube = false
			end
			render(gc,cubeVertices,cubeFaces,2,{200,0,0},8)
		elseif pse_db[elsel][14]==7 then
			if setcube then
				cubeVertices={{-1,-1,0},{-1,1,0},{1,1,0},{1,-1,0},{0,0,1.5},{0,0,-1.5}}
				cubeFaces={{1,2,3,4},{1,2,5},{1,2,6},{3,4,5},{3,4,6}}
				translate(cubeVertices,0,0,-3)
				scale(cubeVertices,0.8,0.8,0.8)
				setcube = false
			end
			render(gc,cubeVertices,cubeFaces,2,{200,0,0},8)
		elseif pse_db[elsel][14]==8 then
			if setcube then
				cubeVertices={{-1,-0.5,-1},{1,-0.5,-1},{-1,0.5,-1},{-1,-0.5,1},{1,0.5,-1},{-1,0.5,1},{1,-0.5,1},{1,0.5,1}}
				cubeFaces={{1,2,5,3},{1,4,6,3},{1,4,7,2},{8,7,4,6},{8,5,3,6},{8,5,2,7}}
				translate(cubeVertices,0,0,-3)
				scale(cubeVertices,0.8,0.8,0.8)
				setcube = false
			end
			render(gc,cubeVertices,cubeFaces,2,{200,0,0},8)
		end
		gc:drawString("Nick Steen",(1)*XRatio,(185)*YRatio,"top")
		gc:drawString("& TI-Planet",(1)*XRatio,(195)*YRatio,"top")
		-- End drawing fct specs
	end
end

---------------
-----TIMER-----
---------------

function on.timer()
	rotate(cubeVertices,math.pi/80,0,0,1)
	platform.window:invalidate(XRatio*100,YRatio*130,XRatio*120,YRatio*90)
end


-----------------------
-----MOUSE ACTIONS-----
-----------------------

function on.mouseMove(x,y)
	if layout=="pse" then
		elsel = 0
		cursor.set("pointer")
		if #pse_link>0 and #pse_order>0 then
			for i=1,#pse_link do
				if x>pse_link[i][1]*XRatio and y>pse_link[i][2]*YRatio and x<(pse_link[i][3]*XRatio+pse_link[i][1]*XRatio) and y<(pse_link[i][4]*YRatio+pse_link[i][2]*YRatio) then
					cursor.set("hand pointer")
					elsel = pse_link[i][5]
					rowsel = pse_link[i][6]
					colsel = pse_link[i][7]
				end
			end
		end
	end
end

function on.mouseDown(x,y)
		if elsel~=0 then
		layout = "specs"
		cursor.set("pointer")
		timer.start(interval)
		if layout~="specs" then
			setcube = true
		end
	end
	platform.window:invalidate()
end

--------------------
-----KEYPRESSES-----
--------------------

function on.escapeKey()
	if layout=="specs" then
		layout="pse"
		timer.stop()
		setcube = true
	end
	cursor.show("pointer")
	platform.window:invalidate()
end

----------------
-----IMAGES-----
----------------

radioactive = image.new("\011\0\0\0\011\0\0\0\0\0\0\0\022\0\0\0\016\0\001\0\0\0\0\0\0\0\192\255\192\255\192\255\192\255\192\255\0\0\0\0\0\0\0\0\0\0\192\255\192\255\192\255\192\255\192\255\192\255\192\255\0\0\0\0\0\0\192\255\0\128\0\128\192\255\192\255\192\255\0\128\0\128\192\255\0\0\192\255\0\128\0\128\0\128\192\255\192\255\192\255\0\128\0\128\0\128\192\255\192\255\0\128\0\128\0\128\224\255\0\128\167\247\0\128\0\128\0\128\192\255\192\255\192\251\192\251\192\251\001\128\0\128\0\128\192\251\192\251\192\251\192\255\192\255\192\255\192\255\192\255\192\255\0\128\192\255\192\255\192\255\192\255\192\255\192\255\192\255\192\255\192\255\0\128\0\128\0\128\192\255\192\255\192\255\192\255\0\0\192\255\192\255\192\255\0\128\0\128\0\128\192\255\192\255\192\255\0\0\0\0\0\0\192\255\0\128\0\128\0\128\0\128\0\128\192\255\0\0\0\0\0\0\0\0\0\0\192\255\192\255\192\255\192\255\192\255\0\0\0\0\0\0")

-------------------------------
-----TINY 3D BY LOIC PUJET-----
-------------------------------


function multiplyMatrix(matrix,vector)
 local x=matrix[1][1]*vector[1]+matrix[1][2]*vector[2]+matrix[1][3]*vector[3]
 local y=matrix[2][1]*vector[1]+matrix[2][2]*vector[2]+matrix[2][3]*vector[3]
 local z=matrix[3][1]*vector[1]+matrix[3][2]*vector[2]+matrix[3][3]*vector[3]
 return x,y,z
end

function rotate(vertices,angle,x,y,z)
 local sum=x+y+z
 x,y,z=x/sum,y/sum,z/sum
 local c,s=math.cos(angle),math.sin(angle)
 local matrix={{x*x+(1-x*x)*c,x*y*(1-c)-z*s,x*z*(1-c)+y*s},{x*y*(1-c)+z*s,y*y+(1-y*y)*c,y*z*(1-c)-x*s},{x*z*(1-c)-y*s,y*z*(1-c)+x*s,z*z+(1-z*z)*c}}
 for i,e in pairs(vertices) do
  vertices[i]={multiplyMatrix(matrix,e)}
 end
end

function translate(vertices,x,y,z)
 for i,e in pairs(vertices) do
  vertices[i]={e[1]+x,e[2]+y,e[3]+z}
 end
end

function scale(vertices,x,y,z)
 for i,e in pairs(vertices) do
  vertices[i]={e[1]*x,e[2]*y,e[3]*z}
 end
end

function width() return platform.window:width() end
function height() return platform.window:height() end

function reverseTable(tbl)
 local tbl2={}
 for i,e in ipairs(tbl) do
  tbl2[#tbl-i+1]=e
 end
 return tbl2
end

function replaceFaces(tbl1,tbl2,faces)
 local faces2={}
 for i,e in pairs(tbl1) do
  for j,e2 in pairs(tbl2) do
   if e2 then
    if e==e2 then
     table.insert(faces2,faces[j])
     tbl2[j]=nil
    end
   end
  end
 end
 return reverseTable(faces2)
end

function sortFaces(vertices,faces)
 local faces2,distTbl,facesTbl={},{},{}
 local middle={}
 local dist,xsum,ysum,zsum=0,0,0,0
 for i,e in pairs(faces) do
  xsum,ysum,zsum=0,0,0,0
  for j,e2 in pairs(e) do
   xsum,ysum,zsum=xsum+vertices[e2][1],ysum+vertices[e2][2],zsum+vertices[e2][3]
  end
  middle={xsum/#e,ysum/#e+5,zsum/#e}
   dist=math.sqrt(middle[1]*middle[1]+middle[2]*middle[2]+middle[3]*middle[3])
  table.insert(distTbl,dist)
  table.insert(facesTbl,dist)
 end
 table.sort(distTbl)
 return replaceFaces(distTbl,facesTbl,faces)
end

function renderFaces(gc,vertices,faces,pos,mode,color)
 local polygon={}
 local faces2=sortFaces(vertices,faces)
 for i,e in pairs(faces2) do
  polygon={}
  drawPoly=true
  for j,f in pairs(faces2[i]) do
   if not pos[f] then
    drawPoly=false
   else
    table.insert(polygon,pos[f][1])
    table.insert(polygon,pos[f][2])
   end
  end
  if drawPoly then
   table.insert(polygon,pos[faces2[i][1]][1])
   table.insert(polygon,pos[faces2[i][1]][2])
   if mode==4 or mode==5 then
    gc:setColorRGB(color[1],color[2],color[3])
    gc:fillPolygon(polygon)
   end
   if mode==2 or mode==3 or mode==4 then
    gc:setColorRGB(0,0,0)
    gc:drawPolyLine(polygon)
   end
  end
 end
end

function renderVertices(gc,pos)
 gc:setColorRGB(0,0,0)
 for i,e in pairs(pos) do
  if e then
   gc:fillRect(e[1]-1,e[2]-1,3,3)
  end
 end
end

function render(gc,vertices,faces,mode,color)
 local yDist,pos=0,{}
 for i,e in pairs(vertices) do
  if e[2]>-5 then
   yDist=5/(e[2]+5)
   table.insert(pos,{e[1]*yDist*25+width()/2,height()/2-e[3]*yDist*25})
  else
   table.insert(pos,false)
  end
 end
 if mode==1 or mode==2 then
  renderVertices(gc,pos)
 end
 if mode==2 or mode==3 or mode==4 or mode==5 then
  renderFaces(gc,vertices,faces,pos,mode,color)
 end
end