- ndless_tests.tns: automated tests for syscalls, Ndless extensions and libndls.
  Run it in nspire_emu or with an RS232 adapter.
- ndless_keys.tns: displays the keys pressed. Used to check key scanning functions 
  and Touchpad support. Run it in nspire_emu or with an RS232 adapter.

Source code is available in src/arm/tests.
