This package contains the MSYS and YAGARTO components required by the Ndless SDK.
This is *NOT* the whole Ndless SDK. Get it from http://ndlessly.wordpress.com .
These components are distributed separately from the Ndless SDK for ligher updates.

INSTALLATION:
 - Copy mingw-get/ and yagarto/ into the Ndless SDK directory, next to _samples/, autoit/, ...
