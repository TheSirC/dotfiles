This MSVC project needs the thirdparty sources to be in place.
