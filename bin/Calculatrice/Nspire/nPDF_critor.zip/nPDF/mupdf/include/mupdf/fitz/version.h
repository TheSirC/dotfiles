#ifndef MUPDF_FITZ_VERSION_H
#define MUPDF_FITZ_VERSION_H
#ifndef FZ_VERSION
#define FZ_VERSION "1.6"
#endif
#endif
