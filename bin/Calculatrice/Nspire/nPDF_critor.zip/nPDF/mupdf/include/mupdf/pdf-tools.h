#ifndef MUPDF_PDF_TOOLS_PDF_H
#define MUPDF_PDF_TOOLS_PDF_H

int pdfclean_main(int argc, char **argv);

#endif